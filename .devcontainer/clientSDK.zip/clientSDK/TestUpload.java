
import com.google.api.client.googleapis.media.MediaHttpUploader;
import com.google.api.client.googleapis.media.MediaHttpUploaderProgressListener;
import com.google.api.client.http.*;
import com.google.api.client.http.apache.v2.ApacheHttpTransport;
import com.visa.vdp.attributes.AuthCredentials;
import com.visa.vdp.enums.AuthType;
import com.visa.vdp.upload.VisaFileUploader;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClients;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.HashSet;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

public class TestUpload {


    public static void main(String[] args) throws Exception {
        uploadFile();
    }
    
    private static SSLContext sslContext(String keystoreFile, String truststoreFile, String password)
 		   throws GeneralSecurityException, IOException {
 		  KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
 		  KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
 		  try (InputStream in = new FileInputStream(keystoreFile)) {
 		   keystore.load(in, password.toCharArray());
 		  }
 		  try (InputStream in = new FileInputStream(truststoreFile)) {
 			  trustStore.load(in, password.toCharArray());
    		  }
 		  KeyManagerFactory keyManagerFactory =
 		    KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
 		  keyManagerFactory.init(keystore, password.toCharArray());

 		  TrustManagerFactory trustManagerFactory =
 		    TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
 		  trustManagerFactory.init(trustStore);

 		  SSLContext sslContext = SSLContext.getInstance("TLS");
 		  sslContext.init(
 		    keyManagerFactory.getKeyManagers(),
 		    trustManagerFactory.getTrustManagers(),
 		    new SecureRandom());

 		  return sslContext;
 		 }

    public static void uploadFile() throws Exception {

    	int connectiontimeout =  120000;
    	int readtimeout = 180000;
        HttpClient httpClient = HttpClients.custom().setSSLContext(sslContext("{{keystore path}}","{{trustStore path}}","{{keystore password}}")).build();
        HttpTransport transport = new ApacheHttpTransport(httpClient, true);

        VisaFileUploader uploader  = new VisaFileUploader.VisaFileUploadBuilder()
                .authType(AuthType.mTLS)
                .authCredentials(new AuthCredentials("{{username_mtls}}","{{password_mtls}}"))
                .httpTransport(transport)
                .build();


        URIBuilder builder = new URIBuilder();
        builder.setScheme("https");
        builder.setHost("{{vdp gateway domain (ex. sandbox.api.visa.com)}}");
        builder.setPath("{{uri path / endpoint details }}");


        URI uri = builder.build();

        Path p = Paths.get("{{path of the file to be uploaded}}");

        HashMap<String, Object> map = new HashMap<>();

        uploader.upload(uri, p,map, connectiontimeout, readtimeout);


    }
}
