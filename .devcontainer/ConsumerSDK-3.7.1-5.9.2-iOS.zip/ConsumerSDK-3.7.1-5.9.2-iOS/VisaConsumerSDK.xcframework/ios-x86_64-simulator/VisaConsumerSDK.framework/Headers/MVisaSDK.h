//
//  MVisaSDK.h
//  MVisaSDK
//
//  Created by Visa Inc. on 6/7/16.
//  Copyright © 2016 Visa Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MVisaSDK.
FOUNDATION_EXPORT double MVisaSDKVersionNumber;

//! Project version string for MVisaSDK.
FOUNDATION_EXPORT const unsigned char MVisaSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MVisaSDK/PublicHeader.h>


