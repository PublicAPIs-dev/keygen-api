/**************************************************************
* Script   : VDSA_SU_CardPayoutsGeneralPreference.js
* Abstract : Suitelet script to create page for Card Payouts General Preference
* Author   : francis.d.s.robes
* Revision History :
***************************************************************
* Version * Date       * Author             * Description
***************************************************************
*   0.1   * 03/06/2019 * francis.d.s.robes  * Initial version
*   0.2   * 03/07/2019 * antonio.m.p.perez  * Added Post method
*   0.3   * 03/08/2019 * jonel.s.francisco  * Visibility of the button
*   0.4   * 03/12/2019 * amico.arthur.v.diaz* Field Arrangement and Help Texts
*   0.5   * 04/02/2019 * antonio.m.p.perez  * Refined the adding of fields
*   0.6   * 04/03/2019 * antonio.m.p.perez  * Moved the Url endpoint and credentials field to the reporting preference subtab
*   0.7   * 01/07/2020 * darryl.d.caparas   * Integration - webhook and tsp
*   0.8   * 02/04/2020 * darryl.d.caparas   * Added Merchant Name for Source Sender Name
*   0.9   * 02/10/2020 * darryl.d.caparas   * Removed character limit on Merchant Name
*   0.10  * 02/11/2020 * jayzar.n.estareja  * Add enrollment notif feature
*   0.11  * 03/03/2020 * jayzar.n.estareja  * Add payment notif feature
*   0.12  * 03/05/2020 * jayzar.n.estareja  * Remove reconciliation and crybersource references
*   0.13  * 03/30/2020 * jayzar.n.estareja  * Update Iframe API
*   0.14  * 04/06/2020 * jayzar.n.estareja  * Password encryption
***************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */

define(['N/ui/serverWidget', 'N/record','N/redirect', 'N/runtime', 'N/error', 'N/search','N/config', 'N/encode'],
function (serverWidget, record, redirect, runtime, error, search, config, encode) {
	/**
	 * Definition of the Suitelet script trigger point.
	 *
	 * @param {Object} context
	 * @param {ServerRequest} context.request - Encapsulation of the incoming request
	 * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
	 * 
	 */

	function onRequest(context) {
		try {
			//Getting the Preference ID from Company Preference.
			var preferenceRecord = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_preference_record' });
			// var deploymentIdParameter = context.request.parameters.reconDepId;

			if (!!preferenceRecord) {

				if (context.request.method == 'GET') {

					//Lookup of the fields in the preference record. 
					var recordLookup = search.lookupFields({
						type: 'customrecord_vdsa_suiteapp_preference',
						id: preferenceRecord,
						//DC--Added Search Results
						columns: ['custrecord_vdsa_tsp_username', 'custrecord_vdsa_tsp_password', 'custrecord_vdsa_tsp_merchant_name',
							'custrecord_vdsa_card_invite_email', 'custrecord_vdsa_email_author_invite', 'custrecord_vdsa_email_body_invite', 'custrecord_vdsa_email_subj_invite',
							'custrecord_vdsa_card_payment_email', 'custrecord_vdsa_email_author_payment', 'custrecord_vdsa_email_body_payment', 'custrecord_vdsa_email_subj_payment',
							'custrecord_vdsa_card_unenrollment_email', 'custrecord_vdsa_email_author_unenroll', 'custrecord_vdsa_email_body_unenrollment', 'custrecord_vdsa_email_subj_unenrollment',
							'custrecord_vdsa_card_expiration_email', 'custrecord_vdsa_email_author_expiration', 'custrecord_vdsa_email_body_expiration', 'custrecord_vdsa_email_subj_expiration',
							'custrecord_vdsa_card_enrollment_email', 'custrecord_vdsa_email_author_enrollment', 'custrecord_vdsa_email_body_enrollment', 'custrecord_vdsa_email_subj_enrollment',
							'custrecord_vdsa_max_num_retries', 'custrecord_vdsa_payout_endpoint',
							'custrecord_vdsa_vendor_mgmt_roles', 'custrecord_vdsa_pymt_processing_roles',
							'custrecord_vdsa_webhook_username', 'custrecord_vdsa_webhook_password', 'custrecord_vdsa_webhook_url',
							'custrecord_vdsa_webhook_registration_id', 'custrecord_vdsa_webhook_api_url',
							'custrecord_vdsa_tsp_access_token_domain','custrecord_vdsa_tsp_access_token_url', 'custrecord_vdsa_tsp_endpoint_url', 'custrecord_vdsa_tsp_iframe_config_url','custrecord_vdsa_card_sender_email'
						]
					});

					//variable declaration of the checkbox in the email notification subtab
					var unenrollSl = recordLookup.custrecord_vdsa_card_unenrollment_email;
					var	cardExpiSl = recordLookup.custrecord_vdsa_card_expiration_email;
					var enrollSl = recordLookup.custrecord_vdsa_card_enrollment_email;
					var inviteSl = recordLookup.custrecord_vdsa_card_invite_email;
					var paymentSl = recordLookup.custrecord_vdsa_card_payment_email;

					//creation of form
					var form = serverWidget.createForm({
						title: 'Card Payouts General Preference'
					});
					form.clientScriptModulePath = './VDSA_CS_GeneralPreferenceFieldChange.js';

					//Creation of Treasury Bank Subtab and fields
					var tbankSub = form.addSubtab({
						id: 'custscript_vdsa_treasury_bank',
						label: 'Corporate Bank'
					});

					//Creation of Email Notification Subtab
					var enotifSub = form.addSubtab({
						id: 'custscript_vdsa_email_notification',
						label: 'Email Notification'
					});

					//DC--Creation of Webhook Registration Subtab
					var webhkSub = form.addSubtab({
						id: 'custscript_vdsa_webhook_registration',
						label: 'Webhook Registration'
					});

					// creation of Corporate Bank Credentials Group
					var corporateBankGroup = form.addFieldGroup({
						id: 'custfield_vdsa_corporate_bank_group',
						label: 'Credentials',
						tab: 'custscript_vdsa_treasury_bank'
					});
					corporateBankGroup.isBorderHidden = true;

					// creation of Payment Disbursement Group
					var paymentDisbursementGroup = form.addFieldGroup({
						id: 'custfield_vdsa_payment_disbursement_group',
						label: 'Payment Disbursement',
						tab: 'custscript_vdsa_treasury_bank'
					});

					// creation of Tokenization Group
					var tokenizationGroup = form.addFieldGroup({
						id: 'custfield_vdsa_tokenization_group',
						label: 'Card Tokenization',
						tab: 'custscript_vdsa_treasury_bank'
					});

					//Add Company Name
					var companyNameGroup = form.addFieldGroup({
						id: 'custfield_vdsa_card_sender_email',
						label: 'Credentials',
						tab: 'custscript_vdsa_email_notification'
					});

					var companyName = createField(form, recordLookup.custrecord_vdsa_card_sender_email, 'custscript_vdsa_card_sender_email',
						'Company Name', 'text', null, 'custfield_vdsa_card_sender_email',
						'This will be used as {companyName} in email actions.');

					companyNameGroup.isBorderHidden = true;

					if (!!companyName){
						var configRecObj = config.load({
							type: config.Type.COMPANY_INFORMATION
						});
						
						companyName.defaultValue = configRecObj.getValue({ fieldId: 'companyname'}); 
					}

					//Creation of unenrollment group in the email notification subtab and the checkbox field
					var emailInvitationGroup = form.addFieldGroup({
						id: 'custfield_vdsa_email_invite_group',
						label: 'Invitation',
						tab: 'custscript_vdsa_email_notification'
					});

					var inviteChkBox = form.addField({
						id: 'custscript_vdsa_invite_email_notif',
						type: serverWidget.FieldType.CHECKBOX,
						label: 'Enable Card Invitation Email Notification',
						container: 'custfield_vdsa_email_invite_group'
					});
					

					//Creation of unenrollment group in the email notification subtab and the checkbox field
					var emailEnrollmentGroup = form.addFieldGroup({
						id: 'custfield_vdsa_email_enrollment_group',
						label: 'Enrollment',
						tab: 'custscript_vdsa_email_notification'
					});

					var enrollChkBox = form.addField({
						id: 'custscript_vdsa_enroll_email_notif',
						type: serverWidget.FieldType.CHECKBOX,
						label: 'Enable Card Enrollment Email Notification',
						container: 'custfield_vdsa_email_enrollment_group'
					});

					var emailUnenrollmentGroup = form.addFieldGroup({
						id: 'custfield_vdsa_email_unenrollment_group',
						label: 'Unenrollment',
						tab: 'custscript_vdsa_email_notification'
					});

					var unenrollChkBox = form.addField({
						id: 'custscript_vdsa_unenroll_email_notif',
						type: serverWidget.FieldType.CHECKBOX,
						label: 'Enable Card Unenrollment Email Notification',
						container: 'custfield_vdsa_email_unenrollment_group'
					});

					// creation of expiration group in the email notification subtab and the checkbox field
					var emailExpiGroup = form.addFieldGroup({
						id: 'custfield_vdsa_email_expiration_group',
						label: 'Expiration',
						tab: 'custscript_vdsa_email_notification'
					});

					var expiChkBox = form.addField({
						id: 'custscript_vdsa_card_expiration',
						type: serverWidget.FieldType.CHECKBOX,
						label: 'Enable Card Expiration Email Notification',
						container: 'custscript_vdsa_email_notification'
					});

					var paymentUnenrollmentGroup = form.addFieldGroup({
						id: 'custfield_vdsa_email_payment_group',
						label: 'Payment',
						tab: 'custscript_vdsa_email_notification'
					});

					var paymentChkBox = form.addField({
						id: 'custscript_vdsa_payment_email_notif',
						type: serverWidget.FieldType.CHECKBOX,
						label: 'Enable Card Payment Email Notification',
						container: 'custfield_vdsa_email_payment_group'
					});

					//if statement for the defaulting of the checkbox
					if (unenrollSl == true) {
						unenrollChkBox.defaultValue = 'T';
					}

					if (inviteSl == true) {
						inviteChkBox.defaultValue = 'T';
					}

					if (enrollSl == true) {
						enrollChkBox.defaultValue = 'T';
					}

					if (cardExpiSl == true) {
						expiChkBox.defaultValue = 'T';
					}

					if (paymentSl == true) {
						paymentChkBox.defaultValue = 'T';
					}

					//Adding of Help Links.	
					unenrollChkBox.setHelpText({
						help: "Check this box to enable Card Unenrollment Email Notification."
					});

					enrollChkBox.setHelpText({
						help: "Check this box to enable Card Enrollment Email Notification."
					});

					expiChkBox.setHelpText({
						help: "Check this box to enable Card Expiration Email Notification."
					});

					var paymentProcRolesArr = convertObjToArray(recordLookup.custrecord_vdsa_pymt_processing_roles);
					var paymentProcRoles = createField(form, paymentProcRolesArr, 'custscript_vdsa_pymt_processing_roles',
						'Payment Processing Roles', 'multiselect', 'role', 'custfield_vdsa_payment_disbursement_group',
						'Select the roles that will be able to process Card Payouts Payments.');

					var retries = createField(form, !!recordLookup.custrecord_vdsa_max_num_retries[0] ? recordLookup.custrecord_vdsa_max_num_retries[0].value : null, 'custscript_vdsa_reprocess_retries',
						'Payment Auto-Reprocessing Count', 'select', 'customlist_vdsa_retry_count', 'custfield_vdsa_payment_disbursement_group',
						'Select the number of retries available for payment processing.');
					retries.isMandatory = true;

					var poEndPoint = createField(form, recordLookup.custrecord_vdsa_payout_endpoint, 'custscript_vdsa_payout_endpoint',
						'Payment API', 'text', null, 'custfield_vdsa_payment_disbursement_group',
						'Payout API from Corporate Bank. The toolkit will connect to the delegated API to send requests for Payment Disbursement. The request will send the amount, the tokenized card, and the vendor id.');
					poEndPoint.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });

					var vendorManagementRolesArr = convertObjToArray(recordLookup.custrecord_vdsa_vendor_mgmt_roles);
					var vendorManagementRoles = createField(form, vendorManagementRolesArr, 'custscript_vdsa_vendor_mgmt_roles',
						'Vendor Management Roles', 'multiselect', 'role', 'custfield_vdsa_tokenization_group',
						'Select the roles that will have access to the Manage Card Payouts button.');

					//DC--Creation of additional TSP Fields
					var user = createField(form, recordLookup.custrecord_vdsa_tsp_username, 'custscript_vdsa_tsp_username',
						'Username', 'text', null, 'custfield_vdsa_corporate_bank_group',
						'Enter your username for the Token Service Provider.');

					var pass = createField(form, recordLookup.custrecord_vdsa_tsp_password, 'custscript_vdsa_tsp_password',
						'Password', 'password', null, 'custfield_vdsa_corporate_bank_group',
						'Enter your password for the Token Service Provider.');

					var merchantName = createField(form, recordLookup.custrecord_vdsa_tsp_merchant_name, 'custscript_vdsa_tsp_merchant_name',
						'Merchant', 'text', null, 'custfield_vdsa_corporate_bank_group',
						'Enter your Merchant Prefix. This will be used when sending payment.');
					merchantName.maxLength = 8;

					var tspAccessTokenUrl = createField(form, recordLookup.custrecord_vdsa_tsp_access_token_url, 'custscript_vdsa_tsp_access_token_url',
						'End-Point URL', 'text', null, 'custfield_vdsa_corporate_bank_group',
						'Enter the Access Token URL. This will enable netsuite to connect to your access point thus providing in return an access token that will be used for card tokenization and payment disbursement.');
					tspAccessTokenUrl.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });
                  
                  var tspAccessTokenDomain = createField(form, recordLookup.custrecord_vdsa_tsp_access_token_domain, 'custscript_vdsa_tsp_access_token_domain',
						'End-Point Domain', 'text', null, 'custfield_vdsa_corporate_bank_group',
						'Provide the your system domain. This will ensure that the password provided will be only used in this domain. Once the password is entered, the toolkit is converting it into a GUID and this guid will be validated against the domain.');
					tspAccessTokenDomain.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });

					// var tspOneTimeCodeUrl = createField(form, recordLookup.custrecord_vdsa_tsp_one_time_code_url, 'custscript_vdsa_tsp_one_time_code_url',
					// 	'One Time Code URL', 'text', null, 'custfield_vdsa_corporate_bank_group',
					// 	'Enter the OTP Url from Corporate Bank.');

					// tspOneTimeCodeUrl.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });

					// var tspActionUrl = createField(form, recordLookup.custrecord_vdsa_tsp_action_url, 'custscript_vdsa_tsp_action_url',
					// 	'Action URL', 'text', null, 'custfield_vdsa_tokenization_group',
					// 	'Enter the Action Url from Corporate Bank.');
					// tspActionUrl.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });

					// var tspIframeBaseUrl = createField(form, recordLookup.custrecord_vdsa_tsp_iframe_base_url, 'custscript_vdsa_tsp_iframe_base_url',
					// 	'iFrame Base URL', 'text', null, 'custfield_vdsa_tokenization_group',
					// 	'Enter the iFrame Base URL from Corporate Bank.');
					// tspIframeBaseUrl.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });

					var tspIframeConfigUrl = createField(form, recordLookup.custrecord_vdsa_tsp_iframe_config_url, 'custscript_vdsa_tsp_iframe_config_url',
						'Iframe API', 'text', null, 'custfield_vdsa_tokenization_group',
						'Iframe Configuration API URL from Corporate Bank. Provide API if you will be using an iframe that was develop on your system, the toolkit will display this on a Suitelet prepared. Using this will require you to send the responses in the webhook.');
						tspIframeConfigUrl.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });

					var tspEndPointUrl = createField(form, recordLookup.custrecord_vdsa_tsp_endpoint_url, 'custscript_vdsa_tsp_endpoint_url',
						'Unenroll Card API', 'text', null, 'custfield_vdsa_tokenization_group',
						'Card API URL from Corporate Bank. This API will be used as a gateway to unenroll card. We will be sending the tokenized card requesting to deactivate it on your system.');
					tspEndPointUrl.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });
                  
                  var tspEndPointUrlAddCard = createField(form, recordLookup.custrecord_vdsa_tsp_endpoint_url, 'custscript_vdsa_tsp_endpoint_url_addcard',
						'Add Card API', 'text', null, 'custfield_vdsa_tokenization_group',
						'Card API URL from Corporate Bank.This will enable the toolkit to enroll card to your system. Unvalidated request will be sent. To adjust the request, you may modify the page through Customization/Scripting/Scripts/ NAME_OF_ADD_CARD_PAGE to add your bank specific validations.');
					tspEndPointUrlAddCard.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });

					//creation of fields for email notification
					var authorInvite = createField(form, !!recordLookup.custrecord_vdsa_email_author_invite[0] ? recordLookup.custrecord_vdsa_email_author_invite[0].value : null, 'custscript_vdsa_author_invite',
						'Email Author', 'select', 'employee', 'custfield_vdsa_email_invite_group',
						'Select the employee record that will be the author of card payouts invitation. <br /><br /> Note: Invitation Email will not' +
						' be sent if this field is empty.');

					var emailSubjInvite = createField(form, recordLookup.custrecord_vdsa_email_subj_invite, 'custscript_vdsa_email_subject_invite',
						'Email Subject', 'text', null, 'custfield_vdsa_email_invite_group',
						'Enter the subject of the email for card payouts invitation.<br/><br/>Vendor name may be used by using' +
						' the following syntax:<br/><br/>{vendorName} = Retrieves the name of the vendor that is not card payouts enrolled.<br/><br/>Example:<br/>' +
						'<br/>Card Payouts Invitation Notification - {vendorName}<br /><br /> Note: Invitation Email will not be sent if this field is empty.');

					var emailInvite = createField(form, recordLookup.custrecord_vdsa_email_body_invite, 'custscript_vdsa_email_invite',
						'Email Body', 'richtext', null, 'custfield_vdsa_email_invite_group',
						'Enter the body of the email for card payouts invitation.<br/><br/>Vendor name may be used by using the following' +
						' syntax:<br/><br/>{vendorName} = Retrieves the name of the vendor that is not card payouts enrolled.<br/><br/>Example:<br/><br/>Hi {vendorName},<br/><br/>This is to notify you that your debit card' +
						' {cardNumber} has been enrolled successfully.<br/><br/>Regards,<br/>Visa Direct Team<br /><br /> Note: Invitation Email will' +
						' not be sent if this field is empty.');

					var authorUnenroll = createField(form, !!recordLookup.custrecord_vdsa_email_author_unenroll[0] ? recordLookup.custrecord_vdsa_email_author_unenroll[0].value : null, 'custscript_vdsa_author_unenroll',
						'Email Author', 'select', 'employee', 'custfield_vdsa_email_unenrollment_group',
						'Select the employee record that will be the author of unenrollment notifications. <br /><br /> Note: Unenrollment Email will not' +
						' be sent if this field is empty.');

					var emailSubjUnenroll = createField(form, recordLookup.custrecord_vdsa_email_subj_unenrollment, 'custscript_vdsa_email_subject_unenroll',
						'Email Subject', 'text', null, 'custfield_vdsa_email_unenrollment_group',
						'Enter the subject of the email for card unenrollment.<br/><br/>Vendor name and card number may be used by using' +
						' the following syntax:<br/><br/>{vendorName} = Retrieves the name of the vendor with unenrolled card.<br/>{cardNumber} = Retrieves the' +
						' card number of the unenrolled card.<br/><br/>Example:<br/>' +
						'<br/>Card Unenrollment Notification - {vendorName}<br /><br /> Note: Unenrollment Email will not be sent if this field is empty.');

					var emailUnenroll = createField(form, recordLookup.custrecord_vdsa_email_body_unenrollment, 'custscript_vdsa_email_unenroll',
						'Email Body', 'richtext', null, 'custfield_vdsa_email_unenrollment_group',
						'Enter the body of the email for card unenrollment.<br/><br/>Vendor name and card number may be used by using the following' +
						' syntax:<br/><br/>{vendorName} = Retrieves the name of the vendor with unenrolled card.<br/>{cardNumber} = Retrieves the card' +
						' number of the unenrolled card.<br/><br/>Example:<br/><br/>Hi {vendorName},<br/><br/>This is to notify you that your debit card' +
						' {cardNumber} has been unenrolled successfully.<br/><br/>Regards,<br/>Visa Direct Team<br /><br /> Note: Unenrollment Email will' +
						' not be sent if this field is empty.');

					var authorEnroll = createField(form, !!recordLookup.custrecord_vdsa_email_author_enrollment[0] ? recordLookup.custrecord_vdsa_email_author_enrollment[0].value : null, 'custscript_vdsa_author_enroll',
						'Email Author', 'select', 'employee', 'custfield_vdsa_email_enrollment_group',
						'Select the employee record that will be the author of enrollment notifications. <br /><br /> Note: Enrollment Email will not' +
						' be sent if this field is empty.');

					var emailSubjEnroll = createField(form, recordLookup.custrecord_vdsa_email_subj_enrollment, 'custscript_vdsa_email_subject_enroll',
						'Email Subject', 'text', null, 'custfield_vdsa_email_enrollment_group',
						'Enter the subject of the email for card enrollment.<br/><br/>Vendor name and card number may be used by using' +
						' the following syntax:<br/><br/>{vendorName} = Retrieves the name of the vendor with enrolled card.<br/>{cardNumber} = Retrieves the' +
						' card number of the unenrolled card.<br/><br/>Example:<br/>' +
						'<br/>Card Enrollment Notification - {vendorName}<br /><br /> Note: Enrollment Email will not be sent if this field is empty.');

					var emailEnroll = createField(form, recordLookup.custrecord_vdsa_email_body_enrollment, 'custscript_vdsa_email_enroll',
						'Email Body', 'richtext', null, 'custfield_vdsa_email_enrollment_group',
						'Enter the body of the email for card enrollment.<br/><br/>Vendor name and card number may be used by using the following' +
						' syntax:<br/><br/>{vendorName} = Retrieves the name of the vendor with enrolled card.<br/>{cardNumber} = Retrieves the card' +
						' number of the enrolled card.<br/><br/>Example:<br/><br/>Hi {vendorName},<br/><br/>This is to notify you that your debit card' +
						' {cardNumber} has been enrolled successfully.<br/><br/>Regards,<br/>Visa Direct Team<br /><br /> Note: Enrollment Email will' +
						' not be sent if this field is empty.');

					var authoExpi = createField(form, !!recordLookup.custrecord_vdsa_email_author_expiration[0] ? recordLookup.custrecord_vdsa_email_author_expiration[0].value : null, 'custscript_vdsa_author_expiration',
						'Email Author', 'select', 'employee', 'custfield_vdsa_email_expiration_group',
						'Select the employee record that will be the author of expiration notifications. <br /><br /> Note: Expiration Email will not be sent if this ' +
						'field is empty.');

					var emailSubjExpi = createField(form, recordLookup.custrecord_vdsa_email_subj_expiration, 'custscript_vdsa_email_subject_expiration',
						'Email Subject', 'text', null, 'custfield_vdsa_email_expiration_group',
						'Enter the subject of the email for card expiration.<br/><br/>Vendor name, card number, and expiration date may be used by using' +
						' the following syntax:<br/><br/>{vendorName} = Retrieves the name of the vendor with expiring card.<br/>{cardNumber} = Retrieves the' +
						' card number of the expiring card.<br/>{expirationDate} = Retrieves the expiration date of the expiring card.<br/><br/>Example:<br/>' +
						'<br/>Card Expiration Notification - {vendorName}<br /><br /> Note: Expiration Email will not be sent if this field is empty.');

					var emailExpi = createField(form, recordLookup.custrecord_vdsa_email_body_expiration, 'custscript_vdsa_email_expiration',
						'Email Body', 'richtext', null, 'custfield_vdsa_email_expiration_group',
						'Enter the body of the email for card expiration.<br/><br/>Vendor name, card number, and expiration date may be used by using the' +
						' following syntax:<br/><br/>{vendorName} = Retrieves the name of the vendor with expiring card.<br/>{cardNumber} = Retrieves the card' +
						' number of the expiring card.<br/>{expirationDate} = Retrieves the expiration date of the expiring card.<br/><br/>Example:<br/><br/>Hi' +
						' {vendorName},<br/><br/>This is to notify you that your debit card {cardNumber} expiring on {expirationDate} is about to be expired.' +
						'<br/><br/>Regards,<br/>Visa Direct Team<br /><br /> Note: Expiration Email will not be sent if this field is empty.');

					var authorPayment = createField(form, !!recordLookup.custrecord_vdsa_email_author_payment[0] ? recordLookup.custrecord_vdsa_email_author_payment[0].value : null, 'custscript_vdsa_author_payment',
						'Email Author', 'select', 'employee', 'custfield_vdsa_email_payment_group',
						'Select the employee record that will be the author of payment notifications. <br /><br /> Note: Payment Email will not be sent if this ' +
						'field is empty.');

					var emailSubjPayment = createField(form, recordLookup.custrecord_vdsa_email_subj_payment, 'custscript_vdsa_email_subject_payment',
						'Email Subject', 'text', null, 'custfield_vdsa_email_payment_group',
						'Enter the subject of the email for card payment.<br/><br/>Vendor name and card number may be used by using' +
						' the following syntax:<br/><br/>{vendorName} = Retrieves the name of the vendor with enrolled card.<br/>{cardNumber} = Retrieves the' +
						' card number of the enrolled card.<br/>{amountTotal} = Retrieves the total amount of payment.<br/>{checkNumber} = Retrieves the check number of the transaction.<br/><br/>Example:<br/>' +
						'<br/>Card Payment Notification - {vendorName}<br /><br /> Note: Payment Email will not be sent if this field is empty.');

					var emailPayment = createField(form, recordLookup.custrecord_vdsa_email_body_payment, 'custscript_vdsa_email_payment',
						'Email Body', 'richtext', null, 'custfield_vdsa_email_payment_group',
						'Enter the body of the email for card payment.<br/><br/>Vendor name and card number date may be used by using the' +
						' following syntax:<br/><br/>{vendorName} = Retrieves the name of the vendor with enrolled card.<br/>{cardNumber} = Retrieves the card' +
						' number of the enrolled card.<br/>{amountTotal} = Retrieves the total amount of payment.<br/>{checkNumber} = Retrieves the check number of the transaction.<br/><br/>Example:<br/><br/>Hi' +
						' {vendorName},<br/><br/>You just received a payment of ${amountTotal} via Card Payouts.<br/>Card Number: {cardNumber}<br/>Transaction Number: {checkNumber}' +
						'<br/><br/>Regards,<br/>Visa Direct Team<br /><br /> Note: Payment Email will not be sent if this field is empty.');

					form.insertField({
						field: unenrollChkBox,
						nextfield: 'custscript_vdsa_author_unenroll'
					});

					form.insertField({
						field: authorUnenroll,
						nextfield: 'custscript_vdsa_email_subject_unenroll'
					});

					form.insertField({
						field: emailSubjUnenroll,
						nextfield: 'custscript_vdsa_email_unenroll'
					});

					form.insertField({
						field: expiChkBox,
						nextfield: 'custscript_vdsa_author_expiration'
					});

					form.insertField({
						field: authoExpi,
						nextfield: 'custscript_vdsa_email_subject_expiration'
					});

					form.insertField({
						field: emailSubjExpi,
						nextfield: 'custscript_vdsa_email_expiration'
					});

					form.insertField({
						field: enrollChkBox,
						nextfield: 'custscript_vdsa_author_enroll'
					});

					form.insertField({
						field: authorEnroll,
						nextfield: 'custscript_vdsa_email_subject_enroll'
					});

					form.insertField({
						field: emailSubjEnroll,
						nextfield: 'custscript_vdsa_email_enroll'
					});

					//DC--Fields for Webhook Registration
					var webhookUserName = createField(form, recordLookup.custrecord_vdsa_webhook_username, 'custscript_vdsa_webhook_username', 'Webhook Username', serverWidget.FieldType.TEXT, null,
						'custscript_vdsa_webhook_registration', 'Enter Webhook Username.');
					var webhookPassword = createField(form, recordLookup.custrecord_vdsa_webhook_password, 'custscript_vdsa_webhook_password', 'Webhook Password', serverWidget.FieldType.PASSWORD, null,
						'custscript_vdsa_webhook_registration', 'Enter Webhook Password.');
					var webhookPwEdit = createField(form, '', 'custscript_vdsa_webhook_pw_edit', 'Webhook Password Edited', serverWidget.FieldType.TEXT, null,
					'custscript_vdsa_webhook_registration', 'Indicated if password was modified.');
					webhookPwEdit.updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
					var webhookUrl = createField(form, recordLookup.custrecord_vdsa_webhook_url, 'custscript_vdsa_webhook_url', 'Webhook External Url', serverWidget.FieldType.TEXT, null,
						'custscript_vdsa_webhook_registration', 'Enter Webhook Url. You may generate your Webhook URL by creating a deployment or using the default deployment through Customization/Scripting/Scripts/VDSA Webhook SU make sure that the deployment is set as Available Without Login to generate an External URL. Paste the External URL here as links contains account specific ids, this is a manual process.');
					// webhookUrl.updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});

					var webhookRegistrationId = createField(form, recordLookup.custrecord_vdsa_webhook_registration_id, 'custscript_vdsa_webhook_registration_id', 'Registration Id', serverWidget.FieldType.TEXT, null, 'custscript_vdsa_webhook_registration', 'This is the Webhook Registration Id. This is a unique identifier that was generated in the toolkit using uuid v4 as part of the request');
					webhookRegistrationId.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });
					if (recordLookup.custrecord_vdsa_webhook_registration_id != '') {
						webhookUrl.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });
					}
					var webhookApiUrl = createField(form, recordLookup.custrecord_vdsa_webhook_api_url, 'custscript_vdsa_webhook_api_url', 'Webhook API', serverWidget.FieldType.TEXT, null, 'custscript_vdsa_webhook_registration', 'This is the Webhook Registrations URL. Provide API where the toolkit will register the Webhook. This API will be used to register the script that will process your responsed via webhook.');
					webhookApiUrl.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });
					// if (recordLookup.custrecord_vdsa_webhook_url == ''){
					// 	webhookUrl.defaultValue = getExternalUrl();
					// }

					var webhookBtns = form.addField({
						id: 'custpage_visa_webhook_buttons',
						type: serverWidget.FieldType.INLINEHTML,
						label: 'webhookBtns',
						container: 'custscript_vdsa_webhook_registration'
					}).updateLayoutType({
						layoutType: serverWidget.FieldLayoutType.OUTSIDEBELOW
					}).updateBreakType({
						breakType: serverWidget.FieldBreakType.STARTROW
					}).defaultValue = ' <button type="button" id="checkStatus" style="text-align: center;margin: 4px 2px;padding: 5px 10px;" class="pgBntG">Check Status</button> <button type="button" style="text-align: center;margin: 4px 2px;padding: 5px 10px;" class="pgBntG" id="activateWebhook">Register</button> <button type="button" style="text-align: center;margin: 4px 2px;padding: 5px 10px;" class="pgBntG" id="updateWebhook">Update</button> <button type="button" style="text-align: center;margin: 4px 2px;padding: 5px 10px;" class="pgBntG" id="deactivateWebhook">Deactivate</button>';

					var secretField = form.addCredentialField({
						id : 'custscript_vdsa_tsp_secret_token',
						label : 'Secret Token',
						restrictToDomains : [recordLookup.custrecord_vdsa_tsp_access_token_domain],
						restrictToScriptIds : [runtime.getCurrentScript().id,
							'customscript_vdsa_backend_server_process',
							'customscript_vdsa_payment_processing_wfa',
							'customscript_vdsa_card_payouts_pref_bknd',
							'customscript_vdsa_vendor_deactivation_ue'
						],
						restrictToCurrentUser : false,
						container: 'custfield_vdsa_corporate_bank_group'
					});
					secretField.updateDisplayType({
						displayType : serverWidget.FieldDisplayType.HIDDEN
					});

					form.addSubmitButton({ label: 'Save' });

					context.response.writePage(form);
				}

				/**
				* POST context
				* This will set the Preference record based on the fields in the Suitelet.
				*/
				else {
					var requestParameter = context.request.parameters;
					var vendorManagementRoles = requestParameter.custscript_vdsa_vendor_mgmt_roles.split("\u0005"),
						paymentProcRoles = requestParameter.custscript_vdsa_pymt_processing_roles.split("\u0005"),
						cardExpirationEmailChk = false,
						unenrollEmailChk = false,
						enrollEmailChk = false,
						inviteEmailChk = false,
						paymentEmailChk = false;

					if (context.request.parameters.custscript_vdsa_card_expiration == 'T') {
						cardExpirationEmailChk = true;
					}
					if (context.request.parameters.custscript_vdsa_invite_email_notif == 'T') {
						inviteEmailChk = true;
					}
					if (context.request.parameters.custscript_vdsa_unenroll_email_notif == 'T') {
						unenrollEmailChk = true;
					}
					if (context.request.parameters.custscript_vdsa_enroll_email_notif == 'T') {
						enrollEmailChk = true;
					}
					if (context.request.parameters.custscript_vdsa_payment_email_notif == 'T') {
						paymentEmailChk = true;
					}

					var fieldValues = {
						custrecord_vdsa_tsp_username: requestParameter.custscript_vdsa_tsp_username,
						// custrecord_vdsa_tsp_password: requestParameter.custscript_vdsa_tsp_password,
						custrecord_vdsa_tsp_merchant_name: requestParameter.custscript_vdsa_tsp_merchant_name,
						custrecord_vdsa_vendor_mgmt_roles: vendorManagementRoles,
						custrecord_vdsa_payout_endpoint: requestParameter.custscript_vdsa_payout_endpoint,
						custrecord_vdsa_card_sender_email:requestParameter.custscript_vdsa_card_sender_email,
						custrecord_vdsa_email_author_unenroll: requestParameter.custscript_vdsa_author_unenroll,
						custrecord_vdsa_email_body_unenrollment: requestParameter.custscript_vdsa_email_unenroll,
						custrecord_vdsa_email_subj_unenrollment: requestParameter.custscript_vdsa_email_subject_unenroll,
						custrecord_vdsa_email_author_invite: requestParameter.custscript_vdsa_author_invite,
						custrecord_vdsa_email_body_invite: requestParameter.custscript_vdsa_email_invite,
						custrecord_vdsa_email_subj_invite: requestParameter.custscript_vdsa_email_subject_invite,
						custrecord_vdsa_email_author_enrollment: requestParameter.custscript_vdsa_author_enroll,
						custrecord_vdsa_email_body_enrollment: requestParameter.custscript_vdsa_email_enroll,
						custrecord_vdsa_email_subj_enrollment: requestParameter.custscript_vdsa_email_subject_enroll,
						custrecord_vdsa_email_author_expiration: requestParameter.custscript_vdsa_author_expiration,
						custrecord_vdsa_email_body_expiration: requestParameter.custscript_vdsa_email_expiration,
						custrecord_vdsa_email_subj_expiration: requestParameter.custscript_vdsa_email_subject_expiration,
						custrecord_vdsa_email_author_payment: requestParameter.custscript_vdsa_author_payment,
						custrecord_vdsa_email_body_payment: requestParameter.custscript_vdsa_email_payment,
						custrecord_vdsa_email_subj_payment: requestParameter.custscript_vdsa_email_subject_payment,
						custrecord_vdsa_max_num_retries: requestParameter.custscript_vdsa_reprocess_retries,
						custrecord_vdsa_card_expiration_email: cardExpirationEmailChk,
						custrecord_vdsa_card_unenrollment_email: unenrollEmailChk,
						custrecord_vdsa_card_enrollment_email: enrollEmailChk,
						custrecord_vdsa_card_invite_email: inviteEmailChk,
						custrecord_vdsa_card_payment_email: paymentEmailChk,
						custrecord_vdsa_pymt_processing_roles: paymentProcRoles,
						//DC--Added Webhook Fields
						custrecord_vdsa_webhook_username: requestParameter.custscript_vdsa_webhook_username,
						// custrecord_vdsa_webhook_password: requestParameter.custscript_vdsa_webhook_password,
						custrecord_vdsa_webhook_url: requestParameter.custscript_vdsa_webhook_url,
						custrecord_vdsa_webhook_registration_id: requestParameter.custscript_vdsa_webhook_registration_id,
						custrecord_vdsa_webhook_api_url: requestParameter.custscript_vdsa_webhook_api_url,
						custrecord_vdsa_tsp_access_token_url: requestParameter.custscript_vdsa_tsp_access_token_url,
                      custrecord_vdsa_tsp_access_token_domain: requestParameter.custscript_vdsa_tsp_access_token_domain,
						// custrecord_vdsa_tsp_one_time_code_url: requestParameter.custscript_vdsa_tsp_one_time_code_url,
						// custrecord_vdsa_tsp_action_url: requestParameter.custscript_vdsa_tsp_action_url,
						// custrecord_vdsa_tsp_iframe_base_url: requestParameter.custscript_vdsa_tsp_iframe_base_url,
						custrecord_vdsa_tsp_iframe_config_url: requestParameter.custscript_vdsa_tsp_iframe_config_url,
						custrecord_vdsa_tsp_endpoint_url: requestParameter.custscript_vdsa_tsp_endpoint_url,
                      	custrecord_vdsa_tsp_endpoint_url_addcard: requestParameter.custscript_vdsa_tsp_endpoint_url_addcard
					};
					if (requestParameter.custscript_vdsa_webhook_pw_edit=='T'){
						/* 
						* Notes on encryption:
						*   NetSuite password fields are hashed using its proprietary SHA1 implementation.
						*   In SS1.0, nlapiEncrypt can generate same SHA1 value.
						*   In SS2.0, 'N/crypto' module is not able to generate the same value with SHA1 hash algorithm.
						* Solution: 
						*   Base64 is used, easiest solution with the current design.
						* Recommedation:
						*   Since password field is not an option, make use of 'N/crypto' module.
						*   This will include design changes as its usable only by server-side scripts.
						*   The webhook registration logic should be transfered to a server-side script.
						*/
						fieldValues.custrecord_vdsa_webhook_password = encode.convert({
							string: requestParameter.custscript_vdsa_webhook_password,
							inputEncoding: encode.Encoding.UTF_8,
							outputEncoding: encode.Encoding.BASE_64
						});
					}
					if (!!requestParameter.custscript_vdsa_tsp_secret_token){
						fieldValues.custrecord_vdsa_tsp_password = requestParameter.custscript_vdsa_tsp_secret_token;
					}

					record.submitFields({
						type: 'customrecord_vdsa_suiteapp_preference',
						id: preferenceRecord,
						values: fieldValues
					});

					var redirectToPage = redirect.toSuitelet({
						scriptId: 'customscript_vdsa_card_payouts_pref',
						deploymentId: 'customdeploy_vdsa_card_payout_preference'
					});

				}

			}

			/**
			* Throws an error if there is no Preference record ID in the Company Details
			*/
			else {
				throw error.create({
					name: 'No Preference Record Selected',
					message: 'Error Loading the Card Payouts General Preference.<br/><br/>You must first create or select a preference record under Setup > Company > Preferences > General Preferences > Custom Preferences > Card Payouts Preference Record'
				}).message;
			}
		} catch (error) {
			log.error('Error Message', error.message);
			throw error;
		}
	}

	/*
	* Function for creating a field in the suitelet.
	*/
	function createField(form, defaultValue, id, label, type, source, container, helpText) {

		var fieldId = form.addField({
			id: id,
			type: type,
			source: source,
			label: label,
			container: container
		});

		if (type=='password'||type==serverWidget.FieldType.PASSWORD){
			fieldId.maxLength = 200;
		}
		fieldId.defaultValue = defaultValue;
		fieldId.setHelpText({ help: helpText });

		return fieldId;
	}

	/*
	*Function for converting the object to array so it can be stored as a field default.
	*/
	function convertObjToArray(object) {
		if (!!object) {
			var returnArray = [];
			for (var keyName in object) {
				returnArray.push(object[keyName].value);
			}
			return returnArray;
		}
		else {
			return null;
		}
	}

	return {
		onRequest: onRequest
	};

});
