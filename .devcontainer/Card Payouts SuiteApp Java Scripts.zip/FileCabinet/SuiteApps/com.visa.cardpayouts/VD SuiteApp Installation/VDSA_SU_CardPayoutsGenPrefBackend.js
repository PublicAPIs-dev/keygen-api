/*************************************************************
 * Script   : VDSA_SU_CardPayoutsGenPrefBackend.js
 * Abstract : A backend suitelet that will process all of the server side
 *             actions for the Card Payouts General Preference page 
 * Author   : jayzar.n.estareja
 * Revision History :
 *************************************************************
 * Version * Date       * Author             * Description
 *************************************************************
 *   0.1   * 04/04/2020 * jayzar.n.estareja * Initial version
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */

define(['../Library/VDSA_LIB_TokenService.js'],

function(VDSA_TSP) {

    function onRequest(context) {
        log.debug('context.request',context.request);
        var payLoad = context.request.parameters;
        var activity = payLoad.activity;
        var url = payLoad.url;
        var username = payLoad.username;
        var password = payLoad.password;
        log.debug('payLoad',payLoad);

        var responseObjectBody = VDSA_TSP.webhookRegistrations(url,username,password,activity);
        log.debug('responseObjectBody',responseObjectBody);

        context.response.setHeader({
            name: 'Content-Type',
            value: 'Application/JSON',
        });
        context.response.write({ 
            output: JSON.stringify(responseObjectBody) 
        });
    }

    return {
        onRequest: onRequest
    };

});