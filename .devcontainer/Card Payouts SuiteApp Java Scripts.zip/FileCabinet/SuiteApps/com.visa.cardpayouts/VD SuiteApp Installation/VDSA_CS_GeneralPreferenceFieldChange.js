/**************************************************************
 * Script   : VDSA_CS_GeneralPreferenceFieldChange.js                            											   
 * Abstract : Client script to reload the Card Payouts General preference page when the Reconciliation Deployment
 *				field is changed				
 * Author   : amico.arthur.v.diaz                                               											   
 * Revision History :                                                            											   
 ***************************************************************
 * Version * Date       * Author             * Description                      											   
 ***************************************************************
 *   0.1   * 04/06/2019 * amico.arthur.v.diaz* Initial version
 *   0.2   * 01/08/2020 * darryl.d.caparas   * Integration - Webhook   
 *   0.3   * 03/05/2020 * jayzar.n.estareja  * Remove reconciliation references
 *   0.4   * 04/06/2020 * jayzar.n.estareja  * Password encryption
 ***************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/url','N/ui/message','N/runtime','N/https', 'N/record'],

function(url, message, runtime, https, record) {
    
	function pageInit(scriptContext){
		var rec = scriptContext.currentRecord;
      
		var webhookRegId = rec.getValue({fieldId: 'custscript_vdsa_webhook_registration_id'});
		// var webhookUser = rec.getValue({fieldId: 'custscript_vdsa_webhook_username'});
		// var webhookPass = rec.getValue({fieldId: 'custscript_vdsa_webhook_password'});
		
		if(webhookRegId==''){
			document.getElementById("checkStatus").style.display = "none";
			document.getElementById("deactivateWebhook").style.display = "none";
			document.getElementById("updateWebhook").style.display = "none";
		
		}else{
			document.getElementById("activateWebhook").style.display = "none";
		}
      
		document.getElementById("checkStatus").onclick = function(){webhookRegistrations(scriptContext,'checkStatus')};
		document.getElementById("activateWebhook").onclick = function(){webhookRegistrations(scriptContext,'activateWebhook')};
		document.getElementById("deactivateWebhook").onclick = function(){webhookRegistrations(scriptContext,'deactivateWebhook')};
      	document.getElementById("updateWebhook").onclick = function(){webhookRegistrations(scriptContext,'updateWebhook')};
     	
	}
	
    function fieldChanged(scriptContext) {
		window.onbeforeunload = null;
		var fieldId = scriptContext.fieldId;
		
		if(fieldId=='custscript_vdsa_webhook_registration_id'){
        	var suiteletURL = url.resolveScript({
				scriptId: 'customscript_vdsa_card_payouts_pref',
				deploymentId: 'customdeploy_vdsa_card_payout_preference',
				returnExternalUrl: false
			});
			window.location.href = suiteletURL;
        }else if(fieldId=='custscript_vdsa_tsp_username' || fieldId=='custscript_vdsa_tsp_password'){
			var rec = scriptContext.currentRecord;
			var secret;
			var uname = rec.getValue({
				fieldId:'custscript_vdsa_tsp_username'
			});
			var pword = rec.getValue({
				fieldId:'custscript_vdsa_tsp_password'
			});
			if (uname!='' && pword!=''){
				secret = btoa(uname + ':' + pword);
			}
			rec.setValue({
				fieldId:'custscript_vdsa_tsp_secret_token',
				value: secret
			});
		}else if(fieldId=='custscript_vdsa_webhook_password'){
			var rec = scriptContext.currentRecord;
			rec.setValue({
				fieldId:'custscript_vdsa_webhook_pw_edit',
				value: 'T'
			});
		}
    }
  
	/* 
	 * Notes on encryption:
	 *   NetSuite password fields are hashed using its proprietary SHA1 implementation.
	 *   In SS1.0, nlapiEncrypt can generate same SHA1 value.
	 *   In SS2.0, 'N/crypto' module is not able to generate the same value with SHA1 hash algorithm.
	 * Solution: 
	 *   Base64 is used, easiest solution with the current design.
	 * Recommedation:
	 *   Since password field is not an option, make use of 'N/crypto' module.
	 *   This will include design changes as its usable only by server-side scripts.
	 *   The webhook registration logic should be transfered to a server-side script.
	 */
	function webhookRegistrations(scriptContext,activity){
		var rec = scriptContext.currentRecord;
		var webhookRegId = rec.getValue({
			fieldId:'custscript_vdsa_webhook_registration_id'
		});
		// console.log(webhookRegId);
		var webhookUserName = rec.getValue({
			fieldId:'custscript_vdsa_webhook_username'
		});
		// console.log(webhookUserName);
		var webhookPassword = rec.getValue({
			fieldId:'custscript_vdsa_webhook_password'
		});
		// console.log(webhookPassword);
		// console.log(activity);
		var webhookUrl = rec.getValue({
			fieldId:'custscript_vdsa_webhook_url'
		});

		try{
			// console.log('try');
			if (webhookUserName!=''&&webhookPassword!='') {
				// moved to server-side due to https.createSecureString
				// var responseObjectBody = VDSA_TSP.webhookRegistrations(webhookUrl,webhookUserName,webhookPassword,activity);
				var backendURL = url.resolveScript({
					scriptId: 'customscript_vdsa_card_payouts_pref_bknd',
					deploymentId: 'customdeploy_vdsa_card_payouts_pref_bknd'
				});
				
				var responseObjectBody = https.post({
					url: backendURL,
					body: {
						activity: activity,
						url: webhookUrl,
						username: webhookUserName,
						password: webhookPassword,
					}
				});
				responseObjectBody = JSON.parse(responseObjectBody.body);
				// console.log(responseObjectBody);

				var successWebhook;
				// console.log(responseObjectBody);
				var registrationID = responseObjectBody.result.registrationId;
				if (activity == 'checkStatus'){
					var responseObjectUserName = responseObjectBody.result.callBackUserName;
					var responseObjectPassword = responseObjectBody.result.callBackPassword;
                  	var decodeWebpass;
                  	try{
                    	decodeWebpass = atob(webhookPassword);
                    }catch(e){ decodeWebpass = ''; }
					if (responseObjectUserName == webhookUserName && responseObjectPassword == decodeWebpass){
						if (responseObjectBody.result.isActive) {
							successWebhook = 'Current Webhook Registration: Active';
						} else {
							throw 'Current Webhook Registration: Inactive';
						}
					}else{
						throw 'No Active Registration found using this credentials';
					}
				}else if(activity == 'activateWebhook'){
					successWebhook = 'Webhook Registration Success. Your Registration ID: '+ registrationID;
				}else if(activity == 'updateWebhook'){
					successWebhook = 'Webhook is now updated on the TSP.';
				}else if(activity == 'deactivateWebhook'){
					webhookUserName = '';
					webhookPassword = '';
					registrationID = '';
					successWebhook = 'Current Registration ID is now deactivated.';              
				}else{
					throw 'Communication Error. Please Try again.';
				}
			} else {
				throw 'Please Enter your Webhook Registration Username and Password';
			}

			if(successWebhook != null){
				message.create({
					title: "Webhook Registration",
					message: successWebhook,
					type: message.Type.CONFIRMATION
				}).show({ duration: 5000 });
			
				if(activity!='checkStatus'){
					var preferenceRecord = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_preference_record' });
					if (!preferenceRecord){
						throw 'Card Payouts Preference Record is not configured in the General Preferences.';
					} else {
						record.submitFields({
							type: 'customrecord_vdsa_suiteapp_preference',
							id: preferenceRecord,
							values: {
								custrecord_vdsa_webhook_username: webhookUserName,
								custrecord_vdsa_webhook_password: btoa(webhookPassword),
								custrecord_vdsa_webhook_registration_id: registrationID,
								custrecord_vdsa_webhook_url: webhookUrl
							}
						});
						// setting this value triggers reload
						rec.setValue({
							fieldId:'custscript_vdsa_webhook_registration_id',
							value: registrationID
						});
					}
				}
			}
		} catch(errMsg) {
			console.log(errMsg);
          	if (!!errMsg.message) {
              	errMsg = errMsg.message;
            }
			message.create({
				title: "Webhook Registration",
				message: errMsg,
				type: message.Type.ERROR
			}).show({ duration: 8000 });
		}
	}

    return {
		pageInit: pageInit,
        fieldChanged: fieldChanged,
      	webhookRegistrations:webhookRegistrations
    };
    
});
