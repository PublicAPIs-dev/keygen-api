/*************************************************************
 * Script   : VDSA_UE_DefaultCardPaymentTreasuryBank.js
 * Abstract : Workflow action script for defaulting the Treasury Bank to the bank account
 * Author   : francis.d.s.robes
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   1.0   * 03/20/2019 * francis.d.s.robes   * Added defaulting of the treasury bank to
 *                                              the bank account
 *   1.1   * 03/21/2019 * gerard.c.villasenor * fixed issue when unsetting of pref treasury bank in the same record
 *   2.0   * 03/27/2019 * gerard.c.villasenor * Added function to unset pref treasury bank to the bank account                     
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define(['N/record'],

function(record) {
   
    /**
     * This method sets the pref treasury bank details to the bank account and 
     * unsets the pref treasury bank when the treasury bank is unpreferred.
     * Function definition to be triggered before record is loaded.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type
     * @Since 2015.2
     */
    function afterSubmit(scriptContext) {

			if (scriptContext.type == scriptContext.UserEventType.DELETE)
				return;
			
			var newdefPay = scriptContext.newRecord;
			var prefTreas = newdefPay.getValue({
				fieldId: 'custrecord_vdsa_pref_treas_bank_details'
			});

			var currTreasBankId = newdefPay.id;
			var prevTreasBankId = newdefPay.getValue({
				fieldId: 'custrecord_vdsa_default_bank_account'
			});

			var bankAcc = newdefPay.getValue({
				fieldId: 'custrecord_vdsa_bank_account'
			});

			var inactiveFld = newdefPay.getValue({
				fieldId: 'isinactive'
			});
			
			if(prefTreas == true && inactiveFld == false){
				
				/* sets the treasury bank as preferred if the current treasury bank is not the same preferred treasury bank on the bank account record */
				if (currTreasBankId != prevTreasBankId){
					
                  	if (!!prevTreasBankId){

                  		/* remove the old treasury bank details that has been set as preferred. */
                     	var removePref = record.submitFields({
                          type: 'customrecord_vdsa_treasury_bank_details',
                          id: prevTreasBankId,
                          values: {
                              'custrecord_vdsa_pref_treas_bank_details': false
                          }
						});
                    }
				
					var setDefaultTreaBank = record.submitFields({
						type: record.Type.ACCOUNT,
						id: bankAcc,
						values: {
							'custrecord_vdsa_def_card_pay_treas_bank': currTreasBankId
						}
					});
				}
			}  else if (prefTreas == true && inactiveFld == true){

				/* unsets the inactivated preferred treasury bank details on the bank account record */
				if (currTreasBankId == prevTreasBankId){
					var setDefaultTreaBank = record.submitFields({
						type: record.Type.ACCOUNT,
						id: bankAcc,
						values: {
							'custrecord_vdsa_def_card_pay_treas_bank': ''
						}
					});
				}

			} else if (currTreasBankId == prevTreasBankId && prefTreas == false){

				/* unsets the treasury bank details if unpreferred. */
				var setDefaultTreaBank = record.submitFields({
					type: record.Type.ACCOUNT,
					id: bankAcc,
					values: {
						'custrecord_vdsa_def_card_pay_treas_bank': ''
					}
				});
			}
		}

    return {
        afterSubmit: afterSubmit
    };
});
