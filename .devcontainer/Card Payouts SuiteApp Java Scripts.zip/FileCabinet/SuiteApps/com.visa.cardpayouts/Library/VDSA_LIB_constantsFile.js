/**
 * VDSA_LIB_constantsFile.js
 * @NApiVersion 2.x
 */
define([],

    function() {
        
        const Constants = {
            // in non-one world accounts there is one subsidiary "Primary Subsidiary" and it is always 1
            PRIMARY_SUBSIDIARY : 1,
            // publisher ID of the Suiteapp
            APP_ID : 'com.visa.cardpayouts',
            // Max number of results return
            MAX_SEARCH_RESULT : 1000,
            HIDDEN_FIELD_POSTFIX: '(Hidden)'
        };
        var Lists = {
            /* Card Payouts Debit Type */
            DebitType: {
                PRIMARY: 1,
                SECONDARY: 2
            },
            /* Card Payouts Payment Status */
            PaymentStatus: {
                PENDING: 1,
                IN_PROGRESS: 2,
                CONFIRMED: 3,
                REJECTED: 4,
                FOR_REPROCESSING: 5,
                OVERRIDDEN: 6
            },
            /* Card Payouts Response Type */
            ActionType: {
                AUTO_RETRY: 1,
                MANUALLY_REPROCESS: 2,
                REJECT: 3,
                ACCEPT: 4
            }
            // CybersourceCardType: {
            //     "Visa": "001",
            //     "Mastercard": "002",
            //     "American Express": "003",
            //     "Discover": "004",
            //     "Diners Club: cards starting with": "005",
            //     "Carte Blanche": "006",
            //     "JCB": "007",
            //     "EnRoute": "014",
            //     "JAL": "021",
            //     "Maestro UK Domestic": "024",
            //     "Delta": "031",
            //     "Visa Electron": "033",
            //     "Dankort": "034",
            //     "Carte Bancaire": "036",
            //     "Carta Si": "037",
            //     "Maestro International": "042",
            //     "GE Money UK card": "043",
            //     "Hipercard (sale only)": "050",
            //     "Elo": "054",
            // }
        };

        /* Card Payouts enroll and unenroll actions */
        var CardAction = {
            CREATE: 'Create',
            UPDATE: 'Update',
            REENROLL: 'Re-enrollment',
            UNENROLL: 'Unenroll',
            ERROR: 'Error'
        };

        var CardType = {
            "Visa": "001",
            "Mastercard": "002",
            "American Express": "003"
        };

        return {
            Lists: Lists,
            Constants: Constants,
            CardAction: CardAction,
            CardType: CardType
        };
    });