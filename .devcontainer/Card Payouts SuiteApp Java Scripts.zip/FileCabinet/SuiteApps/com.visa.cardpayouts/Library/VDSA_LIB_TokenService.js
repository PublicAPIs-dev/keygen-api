/*************************************************************
 * Script   : VDSA_LIB_TokenService.js
 * Abstract : Handles API calls for Corporate Bank integration.
 * Author   : jayzar.n.estareja
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   0.1   * 01/07/2020 * jayzar.n.estareja   * Initial version
 *   0.2   * 01/08/2020 * darryl.d.caparas    * Integration - Webhook
 *   0.3   * 01/13/2020 * jayzar.n.estareja   * Integration - update feature
 *   0.4   * 01/21/2020 * darryl.d.caparas    * Integration - unenroll feature
 *   0.5   * 01/21/2020 * jayzar.n.estareja   * Update get general preference code
 *   0.6   * 01/23/2020 * jayzar.n.estareja   * Used session variable for access token
 *   0.7   * 01/24/2020 * jayzar.n.estareja   * Integration - card payment transaction
 *   0.8   * 02/04/2020 * darryl.d.caparas    * Modified SourceSenderName
 *   0.9   * 02/10/2020 * darryl.d.caparas    * Increase the SourceSenderName to Truncate 25 characters
 *   0.10  * 02/11/2020 * jayzar.n.estareja   * Hide Iframe Optional field
 *   0.11  * 03/30/2020 * jayzar.n.estareja   * Update Iframe API
 *   0.12  * 04/06/2020 * jayzar.n.estareja   * Password encryption
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NModuleScope SameAccount 
 */

define(['N/runtime','N/https', 'N/record', 'N/url', './uuid_v4.js'],

function(runtime, https, record, url, uuidv4) {

    /**
     * Returns the card preference singleton record
     * @return {nlobjrecord} netsuite record object
     */
    function getCardPreferencesRecord() {
        var preferenceRecord = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_preference_record' });
        if (!preferenceRecord){
            // throw error.create({ name: 'Null Card Payouts Preference', message: 'Card Payouts Preference Record is not configured in the General Preferences.', notifyOff: false });
            throw 'Card Payouts Preference Record is not configured in the General Preferences.';
        } else {
            preferenceRecord = record.load({ id: preferenceRecord, type: "customrecord_vdsa_suiteapp_preference" });
        }
        return preferenceRecord;
    }
  
   		  /**************************************************************************************************************
           * Visa Toolkit Note:																 							*
           * 													 	                            						*
           * The requestAccessToken is a function where you will add your bank's corresponding API for authenication	*
           * Variables requestHeaders, requestBody, and requestObject is used to systematically create an API Request	*
           * This function connects to your bank's API to get authentication token										*
           * Add your Response Processing																				*
           * Modify as deemed necessary based on your requirement														*
           **************************************************************************************************************/

    /**
     * Generate token from oAuth server and return authorization header for API usage
     * @return {string} authorization key header
     */
    function requestAccessToken(accessTokenURL, authToken){
        var authHeader = '';

        // check session variables
        var sessionObj = runtime.getCurrentSession();
        log.debug('Auth Header',sessionObj.get({name: "cpAuthHeader"}));
        log.debug('Auth Expire',sessionObj.get({name: "cpAuthExpire"}));
        log.debug('Auth Code',sessionObj.get({name: "cpAuthToken"}));
        var time = new Date();
        
        log.debug('condition1',sessionObj.get({name: "cpAuthHeader"}) == null);
        log.debug('condition2',new Date(sessionObj.get({name: "cpAuthExpire"})) <= time);
        log.debug('condition3',authToken != sessionObj.get({name: "cpAuthToken"}));

        if (sessionObj.get({name: "cpAuthHeader"}) == null // if token not initialized
            || (new Date(sessionObj.get({name: "cpAuthExpire"})) <= time) // if token expired
            || (authToken != sessionObj.get({name: "cpAuthToken"}))){ // if credentials changed
            // genereate new value
            var accessToken = generateNewToken();
            log.debug('Access Token',accessToken);
            // set session variables
            time.setSeconds(time.getSeconds() + parseInt(accessToken.authExpiration) - 600); // deduct 10 mins (allowance for processing)
            sessionObj.set({
                name: "cpAuthExpire",
                value: time
            });
            sessionObj.set({
                name: "cpAuthHeader",
                value: accessToken.authHeader
            });
            sessionObj.set({
                name: "cpAuthToken",
                value: authToken
            });
            authHeader = accessToken.authHeader;
        } else {
            authHeader = sessionObj.get({name: "cpAuthHeader"});
        }

        function generateNewToken(){
		//ADD your token generation API 
          
            /*var secureAuthToken = https.createSecureString({
                input: 'Basic {' + authToken + '}'
            });
            
            var header = {
                "Authorization": secureAuthToken,
                "Content-Type": "application/x-www-form-urlencoded"
            };
            var body = 'grant_type=client_credentials';
            
            var response = https.post({
                url: accessTokenURL,
                headers: header,
                body: body
            });

            log.debug('url',accessTokenURL);
            log.debug('header',header);
            log.debug('body',body);
            log.debug('response',response);
            log.debug('authToken',authToken);

            // var errMsg = error.create({
            //     name: 'Card Payouts Error',
            //     message: 'Error generating Access Token. Please contact administrator.<br>Error message:<br>' + JSON.stringify(response),
            //     notifyOff: false
            // });
            var errMsg = 'Error generating Access Token.';

            if (response.hasOwnProperty('body')) {
                var responseBody = JSON.parse(response.body);
                if (responseBody.token_type && responseBody.access_token){
                    return {
                        authExpiration: responseBody.expires_in,
                        authHeader: responseBody.token_type + ' ' + responseBody.access_token
                    };
                } else if (responseBody.result){
                    throw errMsg + ' ' + responseBody.result + '.';
                } else {
                    throw errMsg + ' ' + responseBody.error + '.';
                }
            } else {
                throw errMsg;
            }*/
        }

        return authHeader;
    }
  
  		  /**************************************************************************************************************
           * Visa Toolkit Note:																 							*
           * 													 	                            						*
           * The enrollToken is a function where you will add your bank's corresponding API for Add Card Iframe     	*
           * Variables requestHeaders, requestBody, and requestObject is used to systematically create an API Request	*
           * Add your Response Processing																				*
           * Modify as deemed necessary based on your requirement														*
           **************************************************************************************************************/

    function enrollToken(vendorId, redirectSuccessURL, redirectFailureURL, vendorDetails){
        var cardPreferencesRec = getCardPreferencesRecord();
        var accessTokenURL = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_access_token_url' });
        var authToken = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_password' });
        var accessToken = requestAccessToken(accessTokenURL, authToken);
        var iframeURL = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_iframe_config_url' });
        var referenceNum = uuidv4();
        redirectSuccessURL = updateRedirectURL(redirectSuccessURL, referenceNum);
        redirectFailureURL = updateRedirectURL(redirectFailureURL, referenceNum);

      // This is your API Request
       /* var requestHeaders = {
            "Accept": "application/json",
            "Authorization": Sample Authorization
        };
        var requestBody = {
            "requestId": referenceNum,
            "customerReferenceNumber": vendorId,
            "firstName": vendorDetails.firstname,
            "lastName": vendorDetails.lastname,
            "zipCode": vendorDetails.billzipcode
        };
        log.debug('requestBody',requestBody);

        var requestObject = https.post({
            body : requestBody,
            headers: requestHeaders,
            url: iframeURL
        }); 
        */

      // Enter your is your Response Processing
      // Process your JSON Response
      // Add Success and Error Messages

    }

    function updateRedirectURL(redirectURL, referenceNum){
        // add or update extId in url
        var overwrite = false;
        var extIdVal = 'extId=' + referenceNum;
        var tempURL = redirectURL.split('?');
        var queries = tempURL[1].split('&');
        for( i = 0; i < queries.length; i++ ) {
            if (queries[i].substring(0,6) == 'extId='){
                queries[i] = extIdVal;
                overwrite = true;
            }
        }
        log.debug('redirectURL',redirectURL);
        return redirectURL = (overwrite) ? [tempURL[0],queries.join('&')].join('?') : redirectURL + '&' + extIdVal;
    }

    /**
     * Create object for deactivating card
     * @param  {string} token 
     * @return {object} HTTPS POST request object
     */
  
  
  		  /**************************************************************************************************************
           * Visa Toolkit Note:																 							*
           * 													 	                            						*
           * The unenrollToken is a function where you will add your bank's corresponding API for Unenroll Card     	*
           * Variables requestHeaders, requestBody, and requestObject is used to systematically create an API Request	*
           * Add your Response Processing																				*
           * Modify as deemed necessary based on your requirement														*
           **************************************************************************************************************/
  
    function unenrollToken(token){

        // load preference record
        var cardPreferencesRec = getCardPreferencesRecord(); 
        var accessTokenURL = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_access_token_url' });
        var endPointURL = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_endpoint_url' });
        var authToken = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_password' });
        var accessToken = requestAccessToken(accessTokenURL, authToken);
	
      // This is your API Request
      
      /*  var requestHeaders = {
            "Accept": "application/json",
            "Authorization": Sample Token
        };
        
        var requestBody = {
            "requestId": uuidv4(),
            "cardToken": token,
            "isActive": false
        };

        var requestObject = https.put({
            body : requestBody,
            headers: requestHeaders,
            url: endPointURL
        });
        */

      // Enter your is your Response Processing
      // Process your JSON Response
      // Add Success and Error Messages
      
    }

    function getTokenDetails(token){
        // load preference record
        var cardPreferencesRec = getCardPreferencesRecord();
        var endPointURL = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_endpoint_url' }) + '/' + token;
        var accessTokenURL = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_access_token_url' });
        var authToken = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_password' });
        var accessToken = requestAccessToken(accessTokenURL, authToken);

        var requestHeaders = {
            "Accept": "application/json",
            "Authorization": accessToken
        };
        
        var requestObject = https.get({
            headers: requestHeaders,
            url: endPointURL
        });

        return requestObject;
    }

    function webhookRegistrations(url, username, password, button){
        var cardPreferencesRec = getCardPreferencesRecord(); 
        var accessTokenURL = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_access_token_url' });
        var apiURL = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_webhook_api_url' });
        var authToken = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_password' });
        var accessToken = requestAccessToken(accessTokenURL, authToken);
        var registrationId = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_webhook_registration_id' });
        
      
      	  /**********************************************************************************************************************
           * Visa Toolkit Note:																 									*
           * 													 	                            								*
           * The webhookRegistrations is a function where you will add your bank's corresponding API for Webhook  	            *
           * Variables requestHeaders, requestBody, and requestObject is used to systematically create an API Request			*
           * Webhook function may differ but currently these are offered: register, update, deactivate, and check status		*
           * Webhooks are optional, you may use webhook for instances that you are using iframe									*
           * In order to received response from iframe, you should define your process in VDSA Webhook SU						*
           * The current design depends on the functionName defined on the Client Script buttons								*
           * Modify as deemed necessary based on your requirement																*
           **********************************************************************************************************************/
      
      //Add your Specific Webhook API Logics
      /*
        var requestHeaders = {
            "Accept": "application/json",
            "Authorization": accessToken
        };
        
        var requestBody = {
            "requestId": uuidv4(),
            "callBackUrl": url,
            "callBackUserName": username,
            "callBackPassword": password,
            "isActive" :true,
        };
        
        var requestObject;
        if (button == 'checkStatus'){
            requestObject = https.get({
                headers: requestHeaders,
                url: apiURL+'/'+registrationId
            });
        } else if(button == 'activateWebhook'){
            requestObject = https.post({
                body: requestBody,
                headers: requestHeaders,
                url: apiURL
            });
        } else if(button == 'updateWebhook'){
            requestObject = https.put({
                headers: requestHeaders,
                body: requestBody,
                url: apiURL +'/'+registrationId
            });
        } else if(button == 'deactivateWebhook'){
            requestObject = https.delete({
                headers: requestHeaders,
                url: apiURL +'/'+registrationId
            });
        } else{
            throw 'Communication Error. Please Try again.';;
        } */
        
       // Add your response processing
    }
  
 		  /**********************************************************************************************************************
           * Visa Toolkit Note:																 									*
           * 													 	                            								*
           * The paymentTransaction is a function where you will add your bank's corresponding API for Payment Transaction  	*
           * Variables requestHeaders, requestBody, and requestObject is used to systematically create an API Request			*
           * Add your Response Processing																						*
           * Modify as deemed necessary based on your requirement																*
           **********************************************************************************************************************/

    function paymentTransaction(token, amount, tranid){
        var cardPreferencesRec = getCardPreferencesRecord();
        var endPointURL = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_payout_endpoint' });
        var accessTokenURL = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_access_token_url' });
        var authToken = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_password' });
        var merchantName = cardPreferencesRec.getValue({ fieldId: 'custrecord_vdsa_tsp_merchant_name' });
        var sourceSenderName = merchantName+' '+tranid;
        var accessToken = requestAccessToken(accessTokenURL, authToken);
		
      	// This is your API Request
      	
        /*var requestHeaders = {
            // "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": accessToken
        };
        
        var requestBody = {
            "requestId": uuidv4(),
            "cardToken": token,
            "amount": (amount*100).toFixed(), // convert amount to cents
        };

        var response = https.post({
            body : requestBody,
            headers: requestHeaders,
            url: endPointURL
        });*/

        // Enter your is your Response Processing
      	// Process your JSON Response
      	// Add Success and Error Messages
    }
    
    return {
        getCardPreferencesRecord: getCardPreferencesRecord,
        enrollToken: enrollToken,
        unenrollToken: unenrollToken,
        getTokenDetails: getTokenDetails,
        webhookRegistrations: webhookRegistrations,
        paymentTransaction: paymentTransaction
    };
    
});
