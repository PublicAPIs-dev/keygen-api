/**
 * @NApiVersion 2.x
 * @NModuleScope SameAccount 
 */

define(['N/https', 'N/runtime', 'N/search', 'N/record', 'N/format', 'N/error'],

    function(https, runtime, search, record, format, error) {


        return {
            // STATIC VALUES
            MAX_PAGE_SIZE: 1000,
                        
            /**
             * This function return more than the max 1000 records for a search
             * @param  {object} options type: type of record to search against
             *                          filters: search filters
             *                          columns: search columns
             *                          id: search id for a pre-existing search
             * @return {Object}         Returns the entire result set of a search
             */
            getAllResults: function(options) {
                var arrResults = [];
                var MAX_SEARCH_SIZE = 1000;

                var searchObj;
                // determine if a search should be loaded or created based on id
                if (options.id) {
                    searchObj = search.load(options);
                    // add additional filters or columns if provided
                    if (options.filters) { searchObj.filters = searchObj.filters.concat(options.filters); }
                    if (options.columns) { searchObj.columns = searchObj.columns.concat(options.columns); }
                } else {
                    searchObj = search.create(options);
                }

                var count = 0;
                var searchResult = searchObj.run();
                // loop through results and concat 1000 results each time
                do {
                    var resultSet = searchResult.getRange({ start: count, end: count + MAX_SEARCH_SIZE }) || [];
                    arrResults = arrResults.concat(resultSet);
                    count += MAX_SEARCH_SIZE;
                } while (resultSet.length === MAX_SEARCH_SIZE);

                return arrResults;
            },

            /**
             * Documents an error with most available meta data into a custom record
             * @param  {object} errorObj The error object generated in the catch statement
             */
            createErrorRecord: function(errorObj) {
                var errorCode = errorObj.code || errorObj.name;
                var netsuiteId = errorObj.id;
                var errorDetails = errorObj.details || errorObj.message || JSON.stringify(errorObj);
                var deploymentId = runtime.getCurrentScript().deploymentId;

                var errorRecord = record.create({ type: 'customrecord_vdsa_card_payouts_error' });
                errorRecord.setValue({ fieldId: 'custrecord_vdsa_error_code', value: errorCode });
                errorRecord.setValue({ fieldId: 'custrecord_vdsa_error_detail', value: errorDetails });
                errorRecord.setValue({ fieldId: 'custrecord_vdsa_error_deployment', value: deploymentId });
                errorRecord.setValue({ fieldId: 'custrecord_vdsa_error_object_string', value: JSON.stringify(errorObj) });
                errorRecord.save();
            },

            /**
             * Parses out netsuite error or javascript error into more readable condensed error
             * @param  {[type]} errorObj [description]
             * @return {[type]}          [description]
             */
            getErrorDetails: function(errorObj) {
                if (errorObj.name !== undefined) {
                    // var errorStack = errorObj.stack ? errorObj.stack.join(',') : '';
                    var errorStack = JSON.stringify(errorObj.errorStack || '');
                    return errorObj.name + '(' + errorObj.lineNumber + ')' + ' | ' + errorObj.message + ' | ' + errorStack;
                } else {
                    return errorObj.toString();
                }
            }
        };
        
    });