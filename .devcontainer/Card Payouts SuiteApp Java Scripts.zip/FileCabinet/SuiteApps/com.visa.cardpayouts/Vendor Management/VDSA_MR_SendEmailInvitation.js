/*************************************************************
 * Script   : VDSA_MR_SendEmailInvite.js
 * Abstract : Map-reduce script to send email to all vendor that are not card payouts enrolled.
 * Author   : darryl.d.caparas
 * Revision History :
 *************************************************************
 * Version * Date       * Author            * Description
 *************************************************************
 *   0.1   * 03/03/2020 * darryl.d.caparas       * Initial version
 *   0.2   * 03/24/2020 * darryl.d.caparas       * Add Filter
 *   0.3   * 03/31/2020 * darryl.d.caparas       * CompanyName for email notifications   
 *************************************************************/
/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 */
define(['N/search', 'N/record', 'N/email', 'N/log', 'N/runtime','N/url'],

    function (search, record, email, log, runtime, url) {

        /**
         * Process the data from the expired credit card from the saved search.
         * Marks the beginning of the Map/Reduce process and generates input data.
         *
         * @typedef {Object} ObjectRef
         * @property {number} id - Internal ID of the record instance
         * @property {string} type - Record type id
         *
         * @return {Array|Object|Search|RecordRef} inputSummary
         * @since 2015.1
         */
        function getInputData() {

            var scriptObj = runtime.getCurrentScript();

            var vendorId = scriptObj.getParameter({
                name: 'custscript_vdsa_vendor_id'
            });
            var vendorIds = vendorId.split(",");
            var vendorList = searchVendor(vendorIds);

            return vendorList;
        }

        /**
         * Mapping of key value pair of the credit card details.
         * Executes when the map entry point is triggered and applies to each key/value pair.
         *
         * @param {MapSummary} context - Data collection containing the key/value pairs to process through the map stage
         * @since 2015.1
         */
        function map(context) {

            var jsonObj = JSON.parse(context.value);

            context.write({
                key: jsonObj.id,
                value: jsonObj
            });
        }

        /**
         * Sending of email to card owner for their visa direct.
         * Executes when the reduce entry point is triggered and applies to each group.
         *
         * @param {ReduceSummary} context - Data collection containing the groups to process through the reduce stage
         * @since 2015.1
         */
        function reduce(context) {

            var preferenceRecord = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_preference_record' }),
                getPreference = preferenceSearch(preferenceRecord),
                scriptObj = runtime.getCurrentScript(),
                jsonObj = JSON.parse(context.values[0]),
                recipients = parseInt(jsonObj.values.internalid.value),
                names = jsonObj.values.entityid,
                author,
                notifEnabled,
                subject,
                merchantName,
                body;
            var cardPayoutsLink = getUrl();

            if (!!getPreference) {
                author = getPreference.custrecord_vdsa_email_author_invite[0].value;
                notifEnabled = getPreference.custrecord_vdsa_card_invite_email;
                subject = emailParser(getPreference.custrecord_vdsa_email_subj_invite, names,null,null);
                merchantName = getPreference.custrecord_vdsa_card_sender_email;
                body = emailParser(getPreference.custrecord_vdsa_email_body_invite, names,merchantName,cardPayoutsLink);                
            }


            //check if card owner is existing and preference for subject, body and notification is enabled, then process
            if (!!subject && !!body && !!notifEnabled && !!recipients) {
                var recordType = 'vendor',
                    recordId = recipients,
                    fieldObj = ['email'];
                var vendObj = lookupValues(recordType, recordId, fieldObj);

                //checks if email of vendor is existing, then send email
                if (!!vendObj.email) {

                    sendEmail(author, recipients, subject, body);
                    var vendorRec = record.submitFields({
                        type: record.Type.VENDOR,
                        id: recipients,
                        values: {
                            'custentity_vdsa_email_invite': true
                        },
                        options: {
                            enableSourcing: false,
                            ignoreMandatoryFields: true
                        }
                    });
                }
            }

            context.write({
                key: jsonObj.id,
                value: jsonObj
            });
        }

        /**
         * Processes any error caught on the other statges
         * Executes when the summarize entry point is triggered and applies to the result set.
         *
         * @param {Summary} summary - Holds statistics regarding the execution of a map/reduce script
         * @since 2015.1
         */
        function summarize(summary) {

            if (summary.inputSummary.error) {
                log.error('Data extraction failed', summary.inputSummary.error);
            }

            summary.mapSummary.errors.iterator().each(function (key, error, executionNo) {
                log.error({
                    title: 'Map error for key: ' + key + ', execution no. ' + executionNo,
                    details: error
                });
                return true;
            });

            summary.reduceSummary.errors.iterator().each(function (key, error) {
                log.error('Error sending email for vendor record ID ' + key, error);
                return true;
            });
        }



        function sendEmail(authorId, recipientId, subject, body) {

            email.send({
                author: authorId,
                recipients: recipientId,
                subject: subject,
                body: body,
            });
        }

        /**
         * This method gets the settings from the SuiteApp preference record
         * settings for email notification enablement, author, subject and body are being retunrned by this function
         */

        function preferenceSearch(preferenceId) {

            if (!!preferenceId) {
                var preferenceSearchResult = search.lookupFields({
                    type: 'customrecord_vdsa_suiteapp_preference',
                    id: preferenceId,
                    columns: ['custrecord_vdsa_email_author_invite', 'custrecord_vdsa_card_invite_email', 'custrecord_vdsa_email_body_invite', 'custrecord_vdsa_email_subj_invite','custrecord_vdsa_card_sender_email']
                });
                return preferenceSearchResult;
            }
            else {
                return null;
            }
        }

        /**
         * Function for replacing the email template set on the suiteapp preference
         * replaces the value indicated for vendor name, card number and expiration date.
         */

        function emailParser(emailText, vendorName, merchantName,cardPayoutsLink) {
            var emailParsed = emailText;

            if (!!emailParsed) {
                emailParsed = emailParsed.replace(/{vendorName}/g, vendorName);
                if(!!merchantName){
                    emailParsed = emailParsed.replace(/{companyName}/g, merchantName);
                }else{
                    emailParsed = emailParsed.replace(/{companyName}/g, 'Card Payouts');
                }
                if(!!cardPayoutsLink){
                    emailParsed = emailParsed.replace(/{cardPayoutsLink}/g, cardPayoutsLink);
                }else{
                    emailParsed = emailParsed.replace(/{cardPayoutsLink}/g, 'netsuite.com');
                }
                return emailParsed;
            }
            else {
                return null;
            }

        }

        /**
         * Function for looking up values
         * this will return the object result of the lookup values
         */
        function lookupValues(recordType, recordId, fieldObj) {

            var lookUpObj = search.lookupFields({
                type: recordType,
                id: recordId,
                columns: fieldObj
            });

            return lookUpObj;
        }

        function searchVendor(vendorId) {

            var filters = [
                search.createFilter({ name: "custentity_vdsa_visa_direct_eligible", operator: search.Operator.IS, values: false }),
                search.createFilter({ name: "email", operator: search.Operator.ISNOTEMPTY, values: true }),
                search.createFilter({ name: "isinactive", operator: search.Operator.IS, values: false }),
                search.createFilter({ name: "internalid", operator: search.Operator.ANYOF, values: vendorId })
            ];

            var columns = [
                search.createColumn({ name: "internalid", label: "Internal ID" }),
                search.createColumn({ name: "entityid", label: "Name" })
            ];

            var vendorsResults = search.create({
                type: "vendor",
                filters: filters,
                columns: columns
            });

            return vendorsResults;
        }

        function getUrl(){
            var output = url.resolveScript({
                scriptId: 'customscript_vdsa_payment_preference_sl',
                deploymentId: 'customdeploy_vdsa_payment_preference_sl',
                returnExternalUrl: false
                });
            return output;
        }

        return {
            getInputData: getInputData,
            map: map,
            reduce: reduce,
            summarize: summarize
        };

    });