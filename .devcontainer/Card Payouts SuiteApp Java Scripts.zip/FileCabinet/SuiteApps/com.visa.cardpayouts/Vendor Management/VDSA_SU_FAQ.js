/*************************************************************
 * Script   : VDSA_SU_FAQ.js
 * Abstract : Handles Centerlink.
 * Author   : darryl.d.caparas
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   0.1   * 04/07/2020 * darryl.d.caparas   * Initial version
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 */

define(['N/ui/serverWidget','N/runtime'],
	function(serverWidget,runtime){

		function onRequest(context){

            var link = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_faq_link' });
            var form = serverWidget.createForm({
                title: 'Redirecting to '+link
            });

            var linkFld = form.addField({
                id: 'custpage_vdsa_link',
                label: 'Link',
                type: serverWidget.FieldType.INLINEHTML
            });
            linkFld.defaultValue = '<script>document.location="'+link+'";</script>';

            context.response.writePage(form);
        }
        
		return {
			onRequest: onRequest
		}
	
});