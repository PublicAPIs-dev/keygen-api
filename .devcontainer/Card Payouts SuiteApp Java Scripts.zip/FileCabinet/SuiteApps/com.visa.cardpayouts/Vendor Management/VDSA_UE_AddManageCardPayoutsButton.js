/*************************************************************
 * Script   : VDSA_UE_AddManageCardPayoutsButton.js
 * Abstract : A user event script to open suitelet for
              managing card payouts of a vendor
 * Author   : amico.arthur.v.diaz
 * Revision History :
 *************************************************************
 * Version * Date       * Author             * Description
 *************************************************************
 *   0.1   * 02/19/2019 * jonel.s.francisco  * Initial version                             
 *   0.2   * 02/19/2019 * jonel.s.francisco  * Added Delete Button                              
 *   0.3   * 02/22/2019 * amico.arthur.v.diaz* Added Client Path      
 *   0.4   * 02/26/2019 * antonio.m.p.perez  * Changed to Manage Card Payouts    
 *   0.5   * 03/08/2019 * jonel.s.francisco  * Changed the button visibility criteria
 *   1.0   * 03/22/2019 * r.v.magbojos       * Restructure for Optimization. Added role eligibility check from preference page.
 *   1.1   * 03/02/2020 * jayzar.n.estareja  * Remove card payouts eligible restriction
 *   1.2   * 03/05/2020 * darryl.d.caparas   * Add Before Submit - Send Invite to Vendor
 *************************************************************/

/**
*@NApiVersion 2.0
*@NScriptType UserEventScript
*/

define(['N/runtime', 'N/search', 'N/email', 'N/record','N/url'],

  function (runtime, search, email, record, url) {

    /**
     * Function to add button on vendor page if eligible and
     * user role is allowed to manage card payouts
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type
     * @param {Form} scriptContext.form - Current form
     * @Since 2015.2
     */
    function beforeLoad(context) {

      if (context.type == 'view') {
        var vendorRec = context.newRecord;
        // var cardPayoutsEligible = vendorRec.getValue({
        //   fieldId: 'custentity_vdsa_visa_direct_eligible'
        // });

        //if (cardPayoutsEligible && roleEligible()) {
        if (roleEligible()) {
          var vendorId = vendorRec.id;

          context.form.addButton({
            id: 'custpage_myaddbutton',
            label: 'Manage Card Payouts',
            functionName: 'onClickFunction(' + vendorId + ')'
          });
          context.form.clientScriptModulePath = './VDSA_CS_TriggerManageCardPayoutsButton.js';
        }
      }
    }

    /**
     * Function to determine if role of current user is eligible to manage
     * card payouts of a vendor as configured in the preference page
     *
     * @return boolean
     */
    function roleEligible() {
      var roleEligible = false;

      var scriptObj = runtime.getCurrentScript();
      var prefId = scriptObj.getParameter({
        name: 'custscript_vdsa_preference_record'
      });

      if (!prefId) {
        return false;
      }

      // Lookup global preference
      var lookupRes = search.lookupFields({
        type: 'customrecord_vdsa_suiteapp_preference',
        id: prefId,
        columns: 'custrecord_vdsa_vendor_mgmt_roles'
      });
      var vendorMgmtRolesArr = lookupRes.custrecord_vdsa_vendor_mgmt_roles;

      // Get current user role
      var currUserRole = runtime.getCurrentUser().role;

      // Check if current user role is in lookup results
      for (var index in vendorMgmtRolesArr) {
        var roleId = vendorMgmtRolesArr[index]['value'];

        if (currUserRole == roleId) {
          roleEligible = true;
          break;
        }
      }

      return roleEligible;
    }

    function afterSubmit(context) {
      if (context.type == 'create') {
        var internalId = context.newRecord.id;
        var vendorRec = search.lookupFields({
          type: search.Type.VENDOR,
          id: internalId,
          columns: [
            'entityid',
            'email'
          ]
        });
        var vendorName = vendorRec.entityid;
        var emailAdd = vendorRec.email;

        log.debug('internalId', internalId);
        log.debug('vendorName', vendorName);
        log.debug('emailAdd', emailAdd);

        if (emailAdd != '') {
          var preferenceRecord = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_preference_record' }),
            getPreference = preferenceSearch(preferenceRecord),
            author,
            notifEnabled,
            subject,
            merchantName,
            body;
            var cardPayoutsLink = getUrl();

          if (!!getPreference) {
            author = getPreference.custrecord_vdsa_email_author_invite[0].value;
            notifEnabled = getPreference.custrecord_vdsa_card_invite_email;
            subject = emailParser(getPreference.custrecord_vdsa_email_subj_invite, vendorName,null,null);
            merchantName = getPreference.custrecord_vdsa_card_sender_email;
            body = emailParser(getPreference.custrecord_vdsa_email_body_invite, vendorName,merchantName,cardPayoutsLink); 
          }

          if (!!subject && !!body && !!notifEnabled && !!emailAdd) {
            email.send({
              author: author,
              recipients: internalId,
              subject: subject,
              body: body
            })
            record.submitFields({
              type: record.Type.VENDOR,
              id: internalId,
              values: {
                'custentity_vdsa_email_invite': true
              }
            });
          }
        }

      }

    }

    function preferenceSearch(preferenceId) {

      if (!!preferenceId) {
        var preferenceSearchResult = search.lookupFields({
          type: 'customrecord_vdsa_suiteapp_preference',
          id: preferenceId,
          columns: ['custrecord_vdsa_email_author_invite', 'custrecord_vdsa_card_invite_email', 'custrecord_vdsa_email_body_invite', 'custrecord_vdsa_email_subj_invite','custrecord_vdsa_card_sender_email']
        });
        return preferenceSearchResult;
      }
      else {
        return null;
      }
    }

    function emailParser(emailText, vendorName, merchantName,cardPayoutsLink) {
      var emailParsed = emailText;

      if (!!emailParsed) {
        emailParsed = emailParsed.replace(/{vendorName}/g, vendorName);
        if(!!merchantName){
            emailParsed = emailParsed.replace(/{companyName}/g, merchantName);
        }else{
            emailParsed = emailParsed.replace(/{companyName}/g, 'Card Payouts');
        }
        if(!!cardPayoutsLink){
            emailParsed = emailParsed.replace(/{cardPayoutsLink}/g, cardPayoutsLink);
        }else{
            emailParsed = emailParsed.replace(/{cardPayoutsLink}/g, 'netsuite.com');
        }
        return emailParsed;
    }
    else {
        return null;
    }

    }

    function getUrl(){
      var output = url.resolveScript({
          scriptId: 'customscript_vdsa_payment_preference_sl',
          deploymentId: 'customdeploy_vdsa_payment_preference_sl',
          returnExternalUrl: false
          });
      return output;
  }

    return {
      beforeLoad: beforeLoad,
      afterSubmit: afterSubmit
    };

  });