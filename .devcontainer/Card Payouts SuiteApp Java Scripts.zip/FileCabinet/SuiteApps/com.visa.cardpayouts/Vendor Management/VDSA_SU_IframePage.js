/*************************************************************
 * Script   : VDSA_SU_IframePage.js
 * Abstract : Custom page for handling iframe to register debit card.
 * Author   : jayzar.n.estareja
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   0.1   * 01/07/2020 * jayzar.n.estareja   * Initial version
 *   0.2   * 01/21/2020 * jayzar.n.estareja   * Remove update feature
 *   0.3   * 02/10/2020 * darryl.d.caparas    * Minor Change on Error Message
 *   0.4   * 03/02/2020 * jayzar.n.estareja   * Remove card payouts eligible restriction
 * 												Add role eligibility restriction
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */

define(['N/runtime', 'N/search', 'N/file', 'N/error'],
	function(runtime, search, file, error){
		function onRequest(context){
			if (context.request.method != 'POST') {
                return;
			}
			// var cpAction = context.request.parameters.cpAction;
			var iframeURL = context.request.parameters.iframeURL;
			var redirectURL = context.request.parameters.redirectURL;

			// validate access
			var vendorId;
            var currentUser = runtime.getCurrentUser();
            var currentUserCenter = currentUser.roleCenter;

            if (currentUserCenter == 'VENDOR') {
                vendorId = currentUser.id;
            } else {
                vendorId = context.request.parameters.vendorId;
			}
			
			if (!vendorId || !roleEligible()) {
                throw error.create({
                    name: 'Access Error',
                    message: 'You are not authorized to view this page.'
                }).message;
            } else {
				// var vendorLookup = search.lookupFields({
				// 	type: search.Type.VENDOR,
				// 	id: vendorId,
				// 	columns: 'custentity_vdsa_visa_direct_eligible'
				// });
				// var vendorEligibility = vendorLookup.custentity_vdsa_visa_direct_eligible;
                if (parseInt(vendorId) < 1) {
                    throw error.create({
                        name: 'Access Error',
                        message: 'You are not authorized to setup a Card Payouts detail for this Vendor.'
					}).message;
				// } else if (Object.keys(vendorLookup).length === 0 && vendorLookup.constructor === Object) {
				// 	throw error.create({
                //         name: 'Access Error',
                //         message: 'Vendor does not exist.'
				// 	}).message;
                // } else if (currentUserCenter == 'VENDOR' && !vendorEligibility){
				// 	throw error.create({
                //         name: 'Access Error',
                //         message: 'You are not authorized to setup your Card Payouts preference because your Vendor record is not Card Payouts Enrolled.' +
                //             'Please contact your Administrator.'
                //     }).message;
				}
			}

			// var logo = file.load({
            //     id: 'SuiteApps/com.visa.cardpayouts/Vendor Management/assets/vdsaicon_transparent.png'
			// }).url;
			var icon = file.load({
                id: 'SuiteApps/com.visa.cardpayouts/Vendor Management/assets/vdsaicon_trns.png'
			}).url;
			var fileObj = file.load({id: 'SuiteApps/com.visa.cardpayouts/Vendor Management/assets/VDSA_SU_IframePage.html'});

			var html = fileObj.getContents();
			html = html.replace('IFRAME', iframeURL);
			// html = html.replace('CPLOGO', logo);
			html = html.replace('CPICON', icon);
			// html = html.replace('CPACTION', cpAction);
			html = html.replace('CPREDIRECT', redirectURL);

			// display html page
			context.response.write(html)
		}

		/**
		 * Function to determine if role of current user is eligible to manage
		 * card payouts of a vendor as configured in the preference page
		 *
		 * @return boolean
		 */
		function roleEligible() {
			var roleEligible = false;

			var scriptObj = runtime.getCurrentScript();
			var prefId = scriptObj.getParameter({
				name: 'custscript_vdsa_preference_record'
			});

			if (!prefId) {
				return false;
			}

			// Lookup global preference
			var lookupRes = search.lookupFields({
				type: 'customrecord_vdsa_suiteapp_preference',
				id: prefId,
				columns: 'custrecord_vdsa_vendor_mgmt_roles'
			});
			var vendorMgmtRolesArr = lookupRes.custrecord_vdsa_vendor_mgmt_roles;

			// Get current user role
			var currUserRole = runtime.getCurrentUser().role;

			// Check if current user role is in lookup results
			for (var index in vendorMgmtRolesArr) {
				var roleId = vendorMgmtRolesArr[index]['value'];
				if (currUserRole == roleId) {
					roleEligible = true;
					break;
				}
			}

			return roleEligible;
		}

		return {
			onRequest: onRequest
		}
	}
);