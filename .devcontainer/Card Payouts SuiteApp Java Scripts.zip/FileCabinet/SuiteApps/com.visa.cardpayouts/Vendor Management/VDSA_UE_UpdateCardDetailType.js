/*************************************************************
 * Script   : VDSA_UE_UpdateCardDetailType
 * Abstract : A User-event script that will set the card type for all card payouts record
 *				when the record is set as primary type. This will prevent vendors from
 *				having two card records with primary type. This will also update the
 *				vendor record to update its primary card type.
 * Author   : amico.arthur.v.diaz
 * Revision History :
 *************************************************************
 * Version * Date       * Author             * Description
 *************************************************************
 *   0.1   * 02/21/2019 * amico.arthur.v.diaz* Initial version                                    
 *   0.2   * 03/07/2019 * antonio.m.p.perez  * Added library for Debit Type 
 *   0.3   * 04/04/2019 * amico.arthur.v.diaz* Updated setting of Primary to Vendor
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
 
define(['N/search','N/record','../Library/VDSA_LIB_constantsFile.js'],

function(search, record, VDSA_CONST) {
	
	/*
	*Main function on After Submit
	*This will check if the detail type is Primary and will set other Card Payouts record as secondary.
	*/
    function afterSubmit(scriptContext) {
		if(scriptContext.type == 'delete'){
			return;
		}
		var currentRecord = scriptContext.newRecord;
		var oldRecord = scriptContext.oldRecord;
		var recordId = currentRecord.getValue({fieldId: 'id'});
		var currentCardDetailType = currentRecord.getValue({fieldId: 'custrecord_vdsa_debit_type'});
		var isInactive = currentRecord.getValue({fieldId: 'isinactive'});
		
		var currentVendor = currentRecord.getValue({fieldId: 'custrecord_vdsa_debit_card_owner'});
		if(!!oldRecord){
			var oldVendor = oldRecord.getValue({fieldId: 'custrecord_vdsa_debit_card_owner'});
      	}
				
		var cardRecordLookup = search.lookupFields({
			type : 'customrecord_vdsa_debit_details',
			id : recordId,
			columns : ['custrecord_vdsa_debit_card_owner']
		});
		
		if(cardRecordLookup.custrecord_vdsa_debit_card_owner.length>0){
			var parentId = cardRecordLookup.custrecord_vdsa_debit_card_owner[0].value;
			
			if(!!parentId){
				if(currentCardDetailType == VDSA_CONST.Lists.DebitType.PRIMARY){
					var tokenSearch = search.create({
						type: 'customrecord_vdsa_debit_details',
						filters: [['custrecord_vdsa_debit_card_owner','anyof',parseInt(parentId)]],
						columns: [{name:'internalid', label: 'Internal ID'}]
					});
					
					var tokenSearchRun = tokenSearch.run();
					var tokenSearchResult = tokenSearchRun.getRange(0,1000);
					var tokenResultLength = tokenSearchResult.length;
						
					for (var resultValue = 0; resultValue < tokenResultLength; resultValue++){
						var result = tokenSearchResult[resultValue];
						var otherToken = result.getValue(result.columns[0]);
						
						if(recordId != otherToken){
							submitFields('customrecord_vdsa_debit_details',otherToken,'custrecord_vdsa_debit_type',VDSA_CONST.Lists.DebitType.SECONDARY);
						}
							
					}
					
					if(!isInactive){
						submitFields('vendor', parentId, 'custentity_vdsa_primary_debit', recordId);
					}
					if(scriptContext.type == 'edit'){
						if(currentVendor != oldVendor){
							if(!!oldVendor){
								submitFields('vendor', parseInt(oldVendor), 'custentity_vdsa_primary_debit', null);
							}	
						}
					}
				}
			}
		}
    }
	
	/*
	*This function is used for updating other Card Payouts record.
	*/
	function submitFields(recType, recordId, fieldId, value){
		var valObj = new Object();
		
		valObj[fieldId] = value;
		
		var recId = record.submitFields({
			type: recType,
			id: parseInt(recordId),
			values: valObj
		});
	} 

    return {
        afterSubmit: afterSubmit
    };
    
});
