/*************************************************************
 * Script   : VDSA_CS_CardPayoutsEmailInvite.js
 * Abstract : Handles Filters for Card Payouts Email Invite Suitelet.
 * Author   : darryl.d.caparas
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   0.1   * 03/23/2020 * darryl.d.caparas       * Initial version
 *************************************************************/

 /**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */

 define(['N/url'],
    function(url){
        function fieldChanged(scriptContext){
            window.onbeforeunload = null;
            if (scriptContext.fieldId == 'custpage_vdsa_filter_sent'){
                var rec = scriptContext.currentRecord;
                var filterSent = rec.getValue({fieldId: 'custpage_vdsa_filter_sent'});
                console.log(filterSent);
                var suiteletURL = url.resolveScript({
                    scriptId: 'customscript_vdsa_card_payouts_invite',
                    deploymentId: 'customdeploy_vdsa_card_payouts_invite',
                    returnExternalUrl: false,
                    params: {'SENT_FILTER': filterSent}
                });

               window.location.href = suiteletURL;
            }

        }
        function refreshPage(){
            location.reload()
        }

        return {
            fieldChanged : fieldChanged,
            refreshPage:refreshPage
        };
        
});