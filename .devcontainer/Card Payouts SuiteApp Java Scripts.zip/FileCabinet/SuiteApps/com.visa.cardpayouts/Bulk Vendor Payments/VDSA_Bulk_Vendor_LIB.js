/**
 * @NApiVersion 2.x
 * @NModuleScope SameAccount 
 */

define(['N/https', 'N/runtime', 'N/search', 'N/record', 'N/format', 'N/file', 'N/error', 'N/ui/serverWidget', '../Library/VDSA_Utility_LIB.js', '../Library/VDSA_LIB_constantsFile.js'],

    function(https, runtime, search, record, format, file, error, serverWidget, utilLib, VDSA_CONST) {

        function getStatusMapping() {
            var bulkVendorStatuses = utilLib.getAllResults({
                type: 'customlist_vdsa_bulk_payments_status',
                columns: ['name'],
            });

            var bulkVendorStatusMapping = {};
            for (var i = 0; i < bulkVendorStatuses.length; i++) {
                var id = bulkVendorStatuses[i].id;
                var name = bulkVendorStatuses[i].getValue({ name: 'name' });
                bulkVendorStatusMapping[name] = id;
            }
            return bulkVendorStatusMapping;
        }

        var STATUS_MAPPING = getStatusMapping();
        // var STATUS_MAPPING = '';

        return {
            STATUS_MAPPING: STATUS_MAPPING,
            isOneWorld: runtime.isFeatureInEffect('Subsidiaries'),
            isClassesEnabled: runtime.isFeatureInEffect('CLASSES'),
            isDepartmentsEnabled: runtime.isFeatureInEffect('DEPARTMENTS'),
            isLocationsEnabled: runtime.isFeatureInEffect('LOCATIONS'),
            // STATUS_MAPPING: function() {
            //     var bulkVendorStatuses = utilLib.getAllResults({
            //         type: 'customlist_vdsa_bulk_payments_status',
            //         columns: ['name'],
            //     });
    
            //     var bulkVendorStatusMapping = {};
            //     for (var i = 0; i < bulkVendorStatuses.length; i++) {
            //         var id = bulkVendorStatuses[i].id;
            //         var name = bulkVendorStatuses[i].getValue({ name: 'name' });
            //         bulkVendorStatusMapping[name] = id;
            //     }
            //     return bulkVendorStatusMapping;
            // },
            /**
             * Adds custom form elements to the form from the assets folder
             * @param {nlobjForm} visaForm NetSuite form object passed in and then returned after being mutated with custom asset data
             */
            addCustomUIAssets: function(visaForm) {

                try {

                    var vendorBillListFieldGroup = visaForm.addFieldGroup({
                        id: 'vendorBillList',
                        label: 'Vendor Bills',
                    });

                    var bundleFolderSearch = search.create({
                        type: "folder",
                        filters: [
                            ["name", "is", VDSA_CONST.Constants.APP_ID]
                        ]
                    }).run().getRange(0, VDSA_CONST.Constants.MAX_SEARCH_RESULT);

                    if (bundleFolderSearch.length !== 1) {
                        throw error.create({ name: 'FOLDER ERROR', message: 'ANOTHER FOLDER HAS UTILIZED THIS SUITEAPP\'S PUBLISHER ID', notifyOff: false });
                    }

                    // should never be more than one folder with this suiteapp name
                    var bundleFolderId = bundleFolderSearch[0].id;
                    var assetResults = search.create({
                        type: "file",
                        filters: [
                            ["folder", "anyof", bundleFolderId],
                            "AND",
                            ["formulatext: {folder}", "is", "Bulk Vendor Payments Assets"],
                        ],
                        columns: [
                            'name',
                            'filetype'
                        ]
                    }).run().getRange(0, VDSA_CONST.Constants.MAX_SEARCH_RESULT);

                    var assetObj = assetResults.map(function(currentValue) {
                        return {
                            id: currentValue.id,
                            name: currentValue.getValue({ name: 'name' }),
                            type: currentValue.getValue({ name: 'filetype' }),
                        };
                    });

                    for (var assetIndex = 0; assetIndex < assetObj.length; assetIndex++) {
                        var assetFile = file.load({
                            id: assetObj[assetIndex].id
                        });
                        log.debug('assetObj', JSON.stringify(assetObj[assetIndex]));
                        var defaultContents = assetFile.getContents();

                        // remove extension and prepend custpage to dynamically create field id
                        var assetFieldId = assetObj[assetIndex].name;
                        assetFieldId = assetFieldId.replace('.', '_');
                        assetFieldId = ('custpage_' + assetFieldId).toLowerCase();

                        switch (assetObj[assetIndex].type) {
                            case 'STYLESHEET': // CSS files
                                defaultContents = '<style>' + defaultContents + '</style>';
                                // FALL THROUGH SWITCH
                            case 'HTMLDOC': // CSS files                        
                                assetFile.getContents();
                                var assetField = visaForm.addField({
                                    id: assetFieldId,
                                    type: serverWidget.FieldType.INLINEHTML,
                                    label: '(Hidden) Asset field for ' + assetObj[assetIndex].name,
                                    container: 'vendorBillList'
                                });

                                assetField.updateLayoutType({
                                    layoutType: serverWidget.FieldLayoutType.OUTSIDE
                                });

                                assetField.updateBreakType({
                                    breakType: serverWidget.FieldBreakType.STARTROW
                                });
                                assetField.defaultValue = defaultContents;
                            case 'PNGIMAGE': // CSS files                        
                                // Header Logo Field. 
                                if (assetObj[assetIndex].name === 'VDSA_Card_Payouts_Icon.png') {
                                    // visaForm.title = "<div class='container-fluid theme-showcase' role='main'>" +
                                    //     "<img src='" + assetFile.url + "' width='25%' height='25%'style='margin-right:20px;'></img><div>" +
                                    //     "</div><font size='5'>Bulk Vendor Payments</font></div>";
                                    visaForm.title =  "<div class='headerSection' role='main'>" +
                                    "<img class='headerIcon' src='" + assetFile.url + "'></img>" +
                                    "<h1 class='headerTitle'>" + visaForm.title + "</h1>" +
                                    "</div>";
                                }

                                break;
                            default:
                        }
                    }

                } catch (errorObj) {
                    // TFLib.createErrorRecord(errorObj);
                    throw error.create({
                        name: 'ASSET_LOOKUP_FAILURE',
                        message: errorObj.message,
                        notifyOff: true
                    });
                    // todo log in custom record (create function that logs details in custom record)
                }

                return visaForm;
            }
            
        };

    });