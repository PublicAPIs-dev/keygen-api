/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 */
define(['N/https', 'N/url', 'N/runtime', 'N/search', 'N/record', 'N/format', 'N/task', 'N/error', 'N/workflow', './VDSA_Bulk_Vendor_LIB.js', '../Library/VDSA_Utility_LIB.js', '../Library/VDSA_LIB_constantsFile.js'],

    function(https, url, runtime, search, record, format, task, error, workflow, bulkLib, utilLib, VDSA_CONST) {



        /**
         * Marks the beginning of the Map/Reduce process and generates input data.
         *
         * @typedef {Object} ObjectRef
         * @property {number} id - Internal ID of the record instance
         * @property {string} type - Record type id
         *
         * @return {Array|Object|Search|RecordRef} inputSummary
         * @since 2015.1
         */
        function getInputData() {
            try {
                log.audit({ title: 'START', details: '<--------------------------------START-------------------------------->' });
                var paymentJobId = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_bvp_payment_job_id' });
                log.audit({ title: 'paymentJobId', details: paymentJobId });
                if (!paymentJobId) throw error.create({
                    name: 'INVALID_INPUT',
                    message: 'No bulk payment job id provided. Terminating',
                    notifyOff: true
                });

                // update parent and child records to "In Progress"
                var parentRec = record.load({
                    type: 'customrecord_vdsa_bulk_vendor_payment',
                    id: paymentJobId,
                    isDynamic: true
                });

                parentRec.setValue({ fieldId: 'custrecord_vdsa_bvp_status', value: bulkLib.STATUS_MAPPING['In Progress'] });

                var lineCount = parentRec.getLineCount({ sublistId: 'recmachcustrecord_vdsa_bvp_parent' });
                for (var lineIndex = 0; lineIndex < lineCount; lineIndex++) {
                    parentRec.selectLine({ sublistId: 'recmachcustrecord_vdsa_bvp_parent', line: lineIndex });
                    parentRec.setCurrentSublistValue({
                        sublistId: 'recmachcustrecord_vdsa_bvp_parent',
                        fieldId: 'custrecord_vsda_bvp_transaction_status',
                        value: bulkLib.STATUS_MAPPING['In Progress'],
                        line: lineIndex
                    });
                    parentRec.commitLine({ sublistId: 'recmachcustrecord_vdsa_bvp_parent', line: lineIndex });
                }

                parentRec.save();

                var filters = [
                    search.createFilter({ name: "internalid", operator: search.Operator.ANYOF, values: [paymentJobId] }),
                ];
                var columns = [
                    search.createColumn({ name: "custrecord_vdsa_bvp_status" }),
                    search.createColumn({ name: "custrecord_vdsa_bvp_ap_account" }),
                    search.createColumn({ name: "custrecord_vdsa_bvp_class" }),
                    search.createColumn({ name: "custrecord_vdsa_bvp_department" }),
                    search.createColumn({ name: "custrecord_vdsa_bvp_location" }),
                    search.createColumn({ name: "custrecord_vdsa_bvp_posting_period" }),
                    search.createColumn({ name: "custrecord_vdsa_bvp_date" }),
                    search.createColumn({ name: "custrecord_vdsa_bvp_treasury_bank" }),
                    search.createColumn({ name: "custrecord_vdsa_bvp_treasury_bank_acct" }),
                    search.createColumn({
                        name: "custrecord_vsda_bvp_discount",
                        join: "CUSTRECORD_VDSA_BVP_PARENT",
                    }),
                    search.createColumn({
                        name: "custrecord_vsda_bvp_payment_amount",
                        join: "CUSTRECORD_VDSA_BVP_PARENT",
                    }),
                    search.createColumn({
                        name: "custrecord_vsda_bvp_transaction",
                        join: "CUSTRECORD_VDSA_BVP_PARENT",
                    }),
                    search.createColumn({
                        name: "custrecord_vsda_bvp_currency",
                        join: "CUSTRECORD_VDSA_BVP_PARENT",
                    }),
                    search.createColumn({
                        name: "custrecord_vsda_bvp_vendor",
                        join: "CUSTRECORD_VDSA_BVP_PARENT",
                    })
                ];

                if (bulkLib.isOneWorld) {
                    columns.push(search.createColumn({ name: "custrecord_vdsa_bvp_subsidiary" }));
                }

                return utilLib.getAllResults({
                    type: 'customrecord_vdsa_bulk_vendor_payment',
                    filters: filters,
                    columns: columns
                });

            } catch (errorObj) {
                log.error({ title: '(getInputData) Search Creation Error', details: JSON.stringify(errorObj) });
                utilLib.createErrorRecord(errorObj);
                throw errorObj;
            }
        }

        /**
         * Executes when the map entry point is triggered and applies to each key/value pair.
         *
         * @param {MapSummary} context - Data collection containing the key/value pairs to process through the map stage
         * @since 2015.1
         */
        function map(context) {
            try {
                // log.audit({ title: '(Map) Context', details: JSON.stringify(context) });
                var mapValue = JSON.parse(context.value);

                var searchResult = mapValue.values;

                var vendor = getStringifiedSearchValue(searchResult['CUSTRECORD_VDSA_BVP_PARENT.custrecord_vsda_bvp_vendor']);
                var currency = getStringifiedSearchValue(searchResult['CUSTRECORD_VDSA_BVP_PARENT.custrecord_vsda_bvp_currency']);

                context.write({
                    key: vendor + '|' + currency,
                    value: {
                        // bill detail from transaction subrecord lines
                        amount: getStringifiedSearchValue(searchResult['CUSTRECORD_VDSA_BVP_PARENT.custrecord_vsda_bvp_payment_amount']),
                        discount: getStringifiedSearchValue(searchResult['CUSTRECORD_VDSA_BVP_PARENT.custrecord_vsda_bvp_discount']),
                        currency: currency,
                        transactionId: getStringifiedSearchValue(searchResult['CUSTRECORD_VDSA_BVP_PARENT.custrecord_vsda_bvp_transaction']),
                        vendor: vendor,
                        // main level info from payment parent record
                        apAccount: getStringifiedSearchValue(searchResult['custrecord_vdsa_bvp_ap_account']),
                        subsidiary: bulkLib.isOneWorld ? getStringifiedSearchValue(searchResult['custrecord_vdsa_bvp_subsidiary']) : VDSA_CONST.Constants.PRIMARY_SUBSIDIARY,
                        classification: getStringifiedSearchValue(searchResult['custrecord_vdsa_bvp_class']),
                        date: getStringifiedSearchValue(searchResult['custrecord_vdsa_bvp_date']),
                        department: getStringifiedSearchValue(searchResult['custrecord_vdsa_bvp_department']),
                        location: getStringifiedSearchValue(searchResult['custrecord_vdsa_bvp_location']),
                        postingPeriod: getStringifiedSearchValue(searchResult['custrecord_vdsa_bvp_posting_period']),
                        status: getStringifiedSearchValue(searchResult['custrecord_vdsa_bvp_status']),
                        treasuryBank: getStringifiedSearchValue(searchResult['custrecord_vdsa_bvp_treasury_bank']),
                        treasuryBankAcct: getStringifiedSearchValue(searchResult['custrecord_vdsa_bvp_treasury_bank_acct']),
                    }
                });

            } catch (errorObj) {
                log.error({ title: '(Map) Search Distribution Error', details: utilLib.getErrorDetails(errorObj) });
                utilLib.createErrorRecord(errorObj);
                throw errorObj;
            }

        }

        /**
         * Executes when the reduce entry point is triggered and applies to each group.
         *
         * @param {ReduceSummary} context - Data collection containing the groups to process through the reduce stage
         * @since 2015.1
         */
        function reduce(context) {
            try {
                // log.audit({ title: '(Reduce) Context: ', details: JSON.stringify(context) });
                var transactions = context.values.map(function(transaction) { return JSON.parse(transaction); });
                var metaDataTran = transactions[0];

                var filters = [
                    search.createFilter({ name: "custrecord_vdsa_debit_type", operator: search.Operator.ANYOF, values: VDSA_CONST.Lists.DebitType.PRIMARY }),
                    search.createFilter({ name: "custrecord_vdsa_debit_card_owner", operator: search.Operator.ANYOF, values: metaDataTran.vendor }),
                    search.createFilter({ name: "isinactive", operator: search.Operator.IS, values: false }),
                ];

                var vendorDebitCards = utilLib.getAllResults({
                    type: 'customrecord_vdsa_debit_details',
                    filters: filters,
                });

                // Don't use transform it will break because payment amount won't update with multiple bills
                var billPayment = record.create({
                    type: record.Type.VENDOR_PAYMENT,
                    isDynamic: true
                });

                // should be a primary card set
                if (vendorDebitCards.length === 0) throw error.create({
                    name: 'NO_PRIMARY_CARD_SPECIFIED',
                    message: 'Vendor does not have a primary card specified.',
                    notifyOff: true
                });

                billPayment.setValue({ fieldId: 'entity', value: metaDataTran.vendor });
                if (bulkLib.isOneWorld) {
                    billPayment.setValue({ fieldId: 'subsidiary', value: metaDataTran.subsidiary });
                }
                billPayment.setValue({ fieldId: 'date', value: metaDataTran.date });
                billPayment.setValue({ fieldId: 'custbody_vdsa_for_visa_direct_payment', value: true });
                billPayment.setValue({ fieldId: 'custbody_vdsa_debit_details', value: parseInt(vendorDebitCards[0].id) });
                billPayment.setValue({ fieldId: 'currency', value: metaDataTran.currency });
                billPayment.setValue({ fieldId: 'account', value: metaDataTran.treasuryBankAcct });
                billPayment.setValue({ fieldId: 'custbody_vdsa_treasury_bank_details', value: metaDataTran.treasuryBank });

                // Flag used to bypass UI role check 
                billPayment.setValue({ fieldId: 'custbody_vdsa_for_bulk_billing', value: true });

                if (metaDataTran.classification) {
                    billPayment.setValue({ fieldId: 'class', value: metaDataTran.classification });
                }

                if (metaDataTran.department) {
                    billPayment.setValue({ fieldId: 'department', value: metaDataTran.department });
                }

                if (metaDataTran.location) {
                    billPayment.setValue({ fieldId: 'location', value: metaDataTran.location });
                }

                for (var tranIndex = 0; tranIndex < transactions.length; tranIndex++) {
                    var applyInvId = transactions[tranIndex].transactionId;
                    var applyInvIndex = billPayment.findSublistLineWithValue({ sublistId: 'apply', fieldId: 'internalid', value: applyInvId });
                    log.debug({ title: 'Transaction: ' + applyInvId, details: 'Index: ' + applyInvIndex + ' Amount: ' + transactions[tranIndex].amount + ' Discount: ' + transactions[tranIndex].discount });

                    billPayment.selectLine({ sublistId: 'apply', line: applyInvIndex });
                    billPayment.setCurrentSublistValue({ sublistId: 'apply', fieldId: 'apply', value: true, line: applyInvIndex });
                    if (transactions[tranIndex].discount) {
                        billPayment.setCurrentSublistValue({ sublistId: 'apply', fieldId: 'disc', value: transactions[tranIndex].discount, line: applyInvIndex });
                    } else {
                        billPayment.setCurrentSublistValue({ sublistId: 'apply', fieldId: 'amount', value: transactions[tranIndex].amount, line: applyInvIndex });
                    }
                    billPayment.commitLine({ sublistId: 'apply', line: applyInvIndex });
                }

                var vendorBillPaymentId = billPayment.save({ enableSourcing: true, ignoreMandatoryFields: true });

                // Trigger workflow to initiate the card payouts
                var workflowInstanceId = workflow.trigger({
                    recordType: record.Type.VENDOR_PAYMENT,
                    recordId: vendorBillPaymentId,
                    workflowId: 'customworkflow_vdsa_payment_processing',
                    actionId: 'workflowaction282',
                    stateId: 'workflowstate99'
                });

            } catch (errorObj) {
                log.error({ title: '(Reduce) Search Parse Error:', details: JSON.stringify(errorObj) });
                utilLib.createErrorRecord(errorObj);
                var errorDetails = errorObj.message || errorObj.toString();
                var updateFields = {
                    custrecord_vsda_bvp_transaction_status: bulkLib.STATUS_MAPPING['Error'],
                    custrecord_vsda_bvp_error_message: errorDetails
                };
                updateRelatedJobRecords(metaDataTran.vendor, metaDataTran.currency, updateFields);
                throw errorObj;
            }

        }

        /**
         * Executes when the summarize entry point is triggered and applies to the result set.
         *
         * @param {Summary} summary - Holds statistics regarding the execution of a map/reduce script
         * @since 2015.1
         */
        function summarize(summary) {
            try {
                var paymentJobId = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_bvp_payment_job_id' });
                var scriptErrors = [];

                if (summary.inputSummary.error !== null) {
                    scriptErrors.push(JSON.stringify(JSON.parse(summary.inputSummary.error).cause));
                }

                summary.mapSummary.errors.iterator().each(function(key, value) {
                    scriptErrors.push(JSON.stringify(JSON.parse(value).cause));
                    return true;
                });

                summary.reduceSummary.errors.iterator().each(function(key, value) {
                    scriptErrors.push(JSON.stringify(JSON.parse(value).cause));
                    return true;
                });

                if (scriptErrors.length > 0) {
                    log.error({ title: scriptErrors.length + ' error(s) occured during script execution', details: scriptErrors.join('\n') });
                } else {
                    log.audit({ title: 'summary', details: 'Script finished execution without errors' });
                }

                var parentRec = record.load({
                    type: 'customrecord_vdsa_bulk_vendor_payment',
                    id: paymentJobId,
                    isDynamic: true
                });

                parentRec.setValue({ fieldId: 'custrecord_vdsa_bvp_status', value: bulkLib.STATUS_MAPPING['Completed'] });

                var lineCount = parentRec.getLineCount({ sublistId: 'recmachcustrecord_vdsa_bvp_parent' });
                for (var lineIndex = 0; lineIndex < lineCount; lineIndex++) {
                    parentRec.selectLine({ sublistId: 'recmachcustrecord_vdsa_bvp_parent', line: lineIndex });
                    var lineStatus = parentRec.getCurrentSublistValue({
                        sublistId: 'recmachcustrecord_vdsa_bvp_parent',
                        fieldId: 'custrecord_vsda_bvp_transaction_status',
                        line: lineIndex
                    });
                    if (lineStatus !== bulkLib.STATUS_MAPPING['Error']) {
                        parentRec.setCurrentSublistValue({
                            sublistId: 'recmachcustrecord_vdsa_bvp_parent',
                            fieldId: 'custrecord_vsda_bvp_transaction_status',
                            value: bulkLib.STATUS_MAPPING['Completed'],
                            line: lineIndex
                        });
                    }
                    parentRec.commitLine({ sublistId: 'recmachcustrecord_vdsa_bvp_parent', line: lineIndex });
                }

                parentRec.save();

                var nextJob = findJobsWithStatus('In Queue');
                if (nextJob) {

                    log.audit({ title: 'NEW Job', details: nextJob });
                    var mrTask = task.create({
                        taskType: task.TaskType.MAP_REDUCE,
                        scriptId: 'customscript_vdsa_payment_creation',
                        deploymentId: 'customdeploy_vdsa_payment_creation',
                        params: { custscript_vdsa_bvp_payment_job_id: nextJob }
                    });

                    var taskId = mrTask.submit();
                }

                log.audit({ title: 'Map Time Total (seconds)', details: summary.mapSummary.seconds });
                log.audit({ title: 'Reduce Time Total (seconds)', details: summary.reduceSummary.seconds });
                log.audit({ title: 'Max Concurrency Utilized ', details: summary.reduceSummary.concurrency });
                log.audit({ title: 'END', details: '<---------------------------------END--------------------------------->' });

            } catch (errorObj) {
                log.error({ title: '(Summary) You were so close Error', details: utilLib.getErrorDetails(errorObj) });
                utilLib.createErrorRecord(errorObj);
                throw errorObj;
            }
        }

        return {
            getInputData: getInputData,
            map: map,
            reduce: reduce,
            summarize: summarize
        };

        function updateRelatedJobRecords(vendor, currency, updateFields) {

            var paymentJobId = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_bvp_payment_job_id' });
            var vendorTransactionResults = utilLib.getAllResults({
                type: "customrecord_vdsa_bulk_vendor_tran",
                filters: [
                    search.createFilter({ name: "custrecord_vdsa_bvp_parent", operator: search.Operator.ANYOF, values: [paymentJobId] }),
                    search.createFilter({ name: "custrecord_vsda_bvp_vendor", operator: search.Operator.ANYOF, values: [vendor] }),
                    search.createFilter({ name: "custrecord_vsda_bvp_currency", operator: search.Operator.ANYOF, values: [currency] }),
                ],
            });

            var MAX_RETRIES = 5;
            var numberOfAttempts = 0;
            var isSuccessfulProcessed = false;
            // multiple records could be reporting errors at once at the same time just doing a simple retry mechanism. 
            while (!isSuccessfulProcessed && numberOfAttempts < MAX_RETRIES) {
                try {
                    // load record to update children from parent due to governance concerns. Could be 1000x of records potentially
                    var parentRec = record.load({
                        type: 'customrecord_vdsa_bulk_vendor_payment',
                        id: paymentJobId,
                        isDynamic: true
                    });

                    // set status to error and detail error message while processing in the error field
                    for (var i = 0; i < vendorTransactionResults.length; i++) {

                        var childErrorRecId = vendorTransactionResults[i].id;
                        var childIndex = parentRec.findSublistLineWithValue({ sublistId: 'recmachcustrecord_vdsa_bvp_parent', fieldId: 'id', value: childErrorRecId });

                        if (childErrorRecId !== -1) {
                            parentRec.selectLine({ sublistId: 'recmachcustrecord_vdsa_bvp_parent', line: childIndex });
                            for (var updateField in updateFields) {
                                parentRec.setCurrentSublistValue({
                                    sublistId: 'recmachcustrecord_vdsa_bvp_parent',
                                    fieldId: updateField,
                                    value: updateFields[updateField],
                                    line: childIndex
                                });
                            }
                            // commit line
                            parentRec.commitLine({ sublistId: 'recmachcustrecord_vdsa_bvp_parent', line: childIndex });
                        }
                    }
                    parentRec.save();
                    isSuccessfulProcessed = true;
                } catch (errObject) {
                    log.debug({ title: 'error setting children', details: JSON.stringify(errObject) });
                    numberOfAttempts++;
                }
            }


            return vendorTransactionResults;
        }

        /**
         * Netsuite stringified results give me a headache. create function to check for values 
         * @param  {[type]} value [description]
         * @return {[type]}       [description]
         */
        function getStringifiedSearchValue(value) {
            if (typeof value === 'object') {
                if (value.length !== 0) {
                    return value[0].value;
                } else {
                    return '';
                }
            } else {
                return value;
            }

        }

        /**
         * searches for any open jobs for Bulk Processing. Returns the record id or null
         */
        function findJobsWithStatus(status) {

            var arrFilters = [
                search.createFilter({ name: 'custrecord_vdsa_bvp_status', operator: search.Operator.ANYOF, values: bulkLib.STATUS_MAPPING[status] })
            ];

            var arrColumns = [
                search.createColumn({ name: 'internalid', sort: search.Sort.ASC }),
                search.createColumn({ name: 'custrecord_vdsa_bvp_status' })
            ];

            var searchObj = search.create({ type: 'customrecord_vdsa_bulk_vendor_payment', filters: arrFilters, columns: arrColumns });
            var searchResults = searchObj.run().getRange({ start: 0, end: 10 });
            return searchResults.length > 0 ? searchResults[0].id : null;
        }

    });