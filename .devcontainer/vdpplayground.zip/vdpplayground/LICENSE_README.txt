# Visa Developer Center Playground
Visa Developer Center Playground is a tool designed exclusively for testing and troubleshooting Visa APIs that are exposed through the platform. It comes integrated with all required authentication methods to connect and get going with VDP APIs.

- Package version: 1.0.0

For more information, please visit [https://developer.visa.com/](https://developer.visa.com/)

## Requirements.

Java 1.8

## Installation & Usage

Please refer to user guide (https://developer.visa.com/pages/visa-developer-center-playground)


##License
**© Copyright 2019 Visa. All Rights Reserved.**

*NOTICE: The software and accompanying information and documentation (together, the “Software”) remain the property of
Visa and its suppliers and affiliates. The Software remains protected by intellectual property
rights and may be covered by U.S. and foreign patents or patent applications. The Software is licensed and not sold.*

*By accessing these Developer Tools, you are agreeing to Visa’s terms of use (developer.visa.com/terms) (“TOU”), privacy policy 
(developer.visa.com/privacy), and the additional terms below (collectively, “Developer Tools Terms”).  Capitalized terms not 
otherwise defined herein shall have the meaning set forth in the TOU.  In the event there is a conflict between the terms of 
the TOU and the additional terms below, the additional terms below shall prevail.*

*License. Subject to and conditioned upon your compliance with the terms and conditions of these Developer Tools Terms and in 
accordance with the Documentation, Visa hereby grants you a personal, nonexclusive, nonsublicensable, nontransferable, revocable 
limited license, solely in the Territory, during the term of the Agreement, to use and reproduce the Developer Tools solely for 
the purpose of developing and testing Applications. Any reproduction or use of the Developer Tools shall include attribution to 
Visa as the source and additionally shall contain all copyright and other proprietary notices or legends found on the original.*

*Open Source.  You shall not incorporate, link, distribute or use any open source or other third party software or code in conjunction
with Confidential Information or the Developer Tools in a way that: (i) creates or purports to create obligations with respect to, or
will disclose or require disclosure of, any Confidential Information or the Developer Tools, including without limitation the distribution
or disclosure of any APIs or source code implementing any APIs, or (ii) grants or purports to grant to any third party any rights to or
immunities under any Visa (or any Affiliates) Intellectual Property Rights or proprietary rights.  Without limiting the generality of the
foregoing, You shall not take any action with regard to Confidential Information or the Developer Tools that would cause these to become 
subject to the terms of a third party or open source license (including, without limitation, any open source license listed 
on http://www.opensource.org/licenses/alphabetical or complying with the Open Source Definition listed on https://opensource.org/osd) or to
disclosure. To the extent that the Developer Tools contain third party components subject to third party licenses, these licenses shall be
provided with the Documentation and shall govern with respect to those components*

*"Developer Tools" means vdcplayground.jar and vdplay.jar (and successor compressed JAR files) made available by Visa to You through the 
feature known by Visa as the “Visa Developer Center Playground,” designed for the purpose of testing and troubleshooting Your Applications 
with the Visa APIs.  Each of the Developer Tools and the Visa APIs may be modified by Visa from time to time. *