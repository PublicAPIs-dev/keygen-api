//
//  QRGenerator.h
//  QRGenerator
//
//  Created by Birani, Bhanu Prakash on 11/8/17.
//  Copyright © 2017 Visa Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for QRGenerator.
FOUNDATION_EXPORT double QRGeneratorVersionNumber;

//! Project version string for QRGenerator.
FOUNDATION_EXPORT const unsigned char QRGeneratorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QRGenerator/PublicHeader.h>


