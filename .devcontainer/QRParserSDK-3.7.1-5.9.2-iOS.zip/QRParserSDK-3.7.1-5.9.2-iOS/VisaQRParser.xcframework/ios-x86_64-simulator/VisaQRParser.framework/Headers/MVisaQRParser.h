//
//  MVisaQRParser.h
//  MVisaQRParser
//
//  Created by Jain, Abhinav on 12/5/16.
//  Copyright © 2016 Visa Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MVisaQRParser.
FOUNDATION_EXPORT double MVisaQRParserVersionNumber;

//! Project version string for MVisaQRParser.
FOUNDATION_EXPORT const unsigned char MVisaQRParserVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MVisaQRParser/PublicHeader.h>

